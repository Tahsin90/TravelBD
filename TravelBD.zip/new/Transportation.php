<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="transportation_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image12.jpg" height="160" width="1332" />

</div>

<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                             <h1>Transportation of Bangladesh</h1>
							 <br>
							 <p>
                                 	
The transport sector of Bangladesh consists of a variety of modes. 
The country being a flat plain, all three modes of surface 
transport, i.e. road, railway and water are widely used in 
carrying both passengers and cargo. <br>
<br>
More than half of Bangladesh have access to an all-weather
 hard surface road within 3 miles distance. There has been
 a dramatic expansion of road network in recent years. In 
 1947 there were only 461.8 kilometers of metalled roads. 
 In 1997, the total length of paved road under the Roads 
 and Highways Department stood at more than 20,000 kilometers. 
 It is estimated that mechanized road transport carry about 70%
 of the country's total passenger and cargo volume. <br>
 <br>
 In recent years. construction of a number of bridges 
 such as the Bangabandhu Jamuna Bridge, Meghna Bridge.
 Meghna-Gumti Bridge, Bangladesh-China Friendship Bridge, 
 Shambhuganj Bridge and Mahananda Bridge have been completed.
 The 4.8 km long Bangabandhu Bridge which has been opened to 
 traffic in June, 1998, is the eleventh longest in the world. 
 It has established a strategic link between the East and the 
 West of Bangladesh has integrated the country, is generating 
 multifaceted benefits to the people and promoting inter-regional 
 trade. Apart from quick movement of goods and passenger traffic,
 it is faci1itating transmission of electricity and natural gas
 and has integrated the telecommunication links.<br>
 <br>
 
 About 32% of the total area of Bangladesh is effectively 
 covered by the railways. State-owned Bangladesh Railway
 operates a track of 2706 kilometer, employs about 60,000
 people, owns a fleet of 307 locomotives, 1240 coaching 
 vehicles and I L643 freight wagons, and provides passenger
 and cargo services through 502 stations.<br>
 <br>
 About two-thirds of Bangladesh is a wetland laced with
 a dense network of rivers, canals and creeks. Water 
 transport is the only means available in nearly 10% 
 of' the total area. The navigable waterways vary between 
 8372 kilometer during the monsoon to 5200 kilometer 
 during the dry season. Bangladesh Inland Water Transport
 Authority has been established by the government for 
 maintenance of navigability of ports and channels while 
 the state-owned BIWTC provide passenger and cargo services
 in inland waterways and coastal areas of the country. <br>
 <br>
 The entire coast along the Bay of Bengal is 710 kilometer 
 long. There are two major ports in the country. Chittagong,
 the oldest port, has been an entry-port for at least 1000
 years. The Mongla port in Khulna region serves the western 
 part of Bangladesh.<br>
 <br>
 There are now 11 operational airports in Bangladesh.
 These are Dhaka, Barisal. Chittagomig. Comilla, Cox' 
 s Bazar, Ishurdi, Jessore, Rajshahi, Syedpur, Sylhet 
 and Thakurgaon. Of these, the airports at Dhaka, Chittagong 
 and Sylhet serve international routes. Air careo and Short
 Take-oft and Landing (STOL) services have been opened to
 the private sector by the government. <br>
 <br>
 The Civil Aviation Authority is a public sector entity
 entrusted to construct, maintain and supervise airports
 and regulate air traffic. The national flag carrier
 Biman flies to 26 international and 8 domestic destinations.<br>
 <br>
 <h2>AIR :: </h2><br>

 Biman, Bangladesh Airlines also connects
 Dhaka with Chittagong, Jessore, Cox's Bazar,
 Rajshahi Saidpur and Sylhet in its 7 domestic
 routes. (Biman, Bangladesh Airlines, <br>
 ph::9560151-9; Enquiry & Reservations). 
 
 <h4>Foreign Airlines : </h4>
 <h5>Trans World Airlines Inc.: <a>Ph:880-2-9552491, 9552208</a> </h5>
 <h5>Air France: <a>Ph: 880-2-9568277, 9563050, 9551338, </a> </h5>
 <h5>Japan Airlines: <a>Ph: 880-2-9129322, 9129710</a> </h5>
 <h5>Indian Airlines: <a>Ph: 880-2-9555915, 9557813, 8912205(Airport) </a> </h5>
 <h5>Kuwait Airways:  <a>Ph: 880-2-9110238, 9118829(City) 8914215(Airport</a> </h5>
 <h5>British Airways: <a> Ph: 880-2-9564869-72, 8914410, 8912467(Airport) </a> </h5>
 <h5>Lufthansa:  <a> Ph: 880-2-8618995, 8611191</a> </h5>
 <h5>Myanmar Airlines International: <a>Ph: 880-2-8810579-80 </a> </h5>
 <h5>United Airlines: <a>Ph: 880-2-9556538-9, 9556505, 9567379</a> </h5>
 <h5>Cathay Pacific: <a>Ph: 880-2-9559390, 9559721, 9557117</a> </h5>
 <h5>Pan Am: <a> Ph: 880-2-9554369</a> </h5>
 <h5>Gulf Air: <a>Ph: 880-2-8113237-40 </a> </h5>
 <h5>Singapore Airlines: <a>Ph: 880-2-8828769, 8828774, 8811504-8 </a> </h5>
 <h5>Emirates: <a> Ph: 880-2-9563825-29, 9563830</a> </h5>
 <h5>Korean Air: <a>Ph: 880-2-9563817-9</a> </h5>
 <h5>Malayasian Airlines: <a>Ph:880-2-9885479, 9885480</a> </h5>
 <h5>Thai International: <a>Ph: 880-2-8314711-9, 8914351(Airport)</a> </h5>
 <h5>Royal Nepal Airlines: <a>Ph:880-2-9550423, 9559353</a> </h5>
 <h5>Philippines Airlines: <a>Ph:880-2-411488</a> </h5>
 <h5>Air litalia: <a>Ph: 880-2-9551673</a> </h5>
 <h5>Continental Airlines: <a>Ph:880-2-9565386-1,</a> </h5>
<br>

<h2>Rail: </h2>
 The Bangladesh Railway provides an efficient 
 service to places of interest such as Chittagong,
 Sylhet, Khulna, Mymensingh, Bogra, Rajshahi, Dinajpur 
 starting from Dhaka. The inter-city Express Service 
 is available to and from important cities at cheap fares.<br>
 <br>
 
 <h2>Waterways: </h2>
 Country-Made boats are the most widely used carrier 
 one can see in the river and rivulets. These carry passengers
 and merchandise on a large scale. The landscape of Bangladesh
 is dominated by about 250 rivers which flow essentially north-sourth.
 The alluvial flood plain formed by these rivers covers most of the
 country. Wherever there is a river and a village, a launch or steamer
 will ply for trade. A journey by Rocket Steamer service from Dhaka
 (Sadarghat) to Khulna, the gateway to Sundarbans is a rewarding experience.<br>
 <br>
 <h2>Bus/Coach Service: </h2>
  Road transport in Bangladesh is a private sector 
  affair operating predominantly in domestic routes.
  Rates are among the cheapest in the world. Express
  and non stop services are available to principal 
  towns from Gabtoli, Saidabad and Mohakhai bus
  terminals in Dhaka. The Bangladesh Road Transport
  Corporation (BRTC) also maintains a countrywide 
  network of bus services. Recently they have 
  introduced Dhaka - Calcutta - Dhaka direct 
  daily bus services via Benapole, Jessore. 
  <br>
  <br>
  
  <h2>Car Rental </h2>
  Private car hire service is available in Dhaka
  and some other major cities. Bangladesh Parjatan
  Corporation (BPC), a government organization, has 
  a fleet of air-conditioned and non air-conditioned
  cars, microbuses and jeeps. Besides they offer 
  transfer service for tourists between Dhaka airport 
  and main city points or hotels. <br>

 
 
                             </p>

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>