       <?php
	   
	   error_reporting(E_ALL ^ E_DEPRECATED);
	   
	   mysql_connect("localhost","root","");
       mysql_select_db("project");
	   
	   
	   error_reporting( error_reporting() & ~E_NOTICE );
	   
	   $getquery=mysql_query("SELECT * FROM comment ORDER BY id DESC");
	   while($rows=mysql_fetch_assoc($getquery))
	   {
		   $id=$rows['id'];
		   $name=$rows['name'];
		   $email=$rows['email'];
		   $comment=$rows['comment'];
		   
		     
	   }
	   
	   
	   ?>