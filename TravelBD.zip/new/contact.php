﻿<?php
	include 'config.php';
	
?>


<?php


error_reporting(E_ALL ^ E_DEPRECATED);

mysql_connect("localhost","root","");
mysql_select_db("project");

error_reporting( error_reporting() & ~E_NOTICE );


$name=$_POST['name'];
$email=$_POST['email'];
$comment=$_POST['comment'];
$submit=$_POST['submit'];


If(isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$comment=$_POST['comment'];

If($name && $comment && $email)
{
	$insert=mysql_query("INSERT INTO comment (name,comment,email) VALUES('$name','$comment','$email')");
}

else
{
	echo "please fill out all the fields ";
}
}﻿


?>




<html>
<head>

<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="contact_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image16.jpg" height="400" width="1332" />


<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>
	   
	   
	   
	   <form class="form" action="contact.php" method="POST">
	   
	   <h2>Contact Form</h2>
	   
	   <table>
	   <tr><td>Name : </tr></td>
	   <tr><td><input type="text" name="name" /></td></tr>
	   <tr><td>email : </tr></td>
	   <tr><td><input type="email" name="email" /></td></tr>
	   <tr><td colspan="2"> Comment : </td></tr>
	   <tr><td colspan="2"><textarea rows="08" cols="50" name="comment"></textarea> </td></tr>
	    <tr><td colspan="2"><input type="submit" name="submit" value="comment" /></textarea> </td></tr>
	   </table>
	   
	   <br><br>
	   
	    <iframe class="comment" src="connect.php" width="650px" height="950px">

	   </iframe> 
	   
	   
	   </form>
	   

	   
	   

<div class="main">

            <p>
			<br><br><br><br>
			
			mim<br>
			mim@gmail.com<br>
			01743558400
			<br><br><br>
			
			sadia<br>
			sadia@gmail.com<br>
			01521545664
			
			<br><br><br>
			
			TravelBD.com<br>
			AUST<br>
			141-142 Love Road,<br>
			Tejgaon,Dhaka.
			

</p>			

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
