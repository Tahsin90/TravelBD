<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="distance_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image16.jpg" height="400" width="1332" />


<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>
	   


<div class="main">

		

<h1>Distance City to City</h1><br><br>

<table>
  <thead>
    <tr>
      <th> </th>
      <th>Dhaka</th>
      <th>Barisal</th>
      <th>Bogra</th>
      <th>chittagong</th>
      <th>Comilla</th>
      <th>Dinajpur</th>
      <th>Faridpur</th>
      <th>Jessore</th>
      <th>Khulna</th>
      <th>Kushtia</th>
      <th>Mymensing</th>
      <th>Noakhali</th>
      <th>Pabna</th>
      <th>Rajshahi</th>
      <th>Rangpur</th>
      <th>Rangamati</th>
      <th>sylhet</th>
      
    </tr>
  </thead>
  <tbody id="1">
    <tr>
      <th>Dhaka</th>
      <td>-</td>
      <td>277</td>
      <td>229</td>
      <td>264</td>
      <td>97</td>
      <td>414</td>
      <td>145</td>
      <td>274</td>
      <td>335</td>
      <td>277</td>
      <td>193</td>
      <td>192</td>
      <td>161</td>
      <td>270</td>
      <td>335</td>
      <td>340</td>
      <td>346</td>
    </tr>
    <tr>
      <th>Barisal</th>
      <td>277</td>
      <td>-</td>
      <td>438</td>
      <td>541</td>
      <td>373</td>
      <td>673</td>
      <td>132</td>
      <td>261</td>
      <td>322</td>
      <td>264</td>
      <td>470</td>
      <td>468</td>
      <td>280</td>
      <td>401</td>
      <td>594</td>
      <td>616</td>
      <td>623</td>
    </tr>
    <tr>
      <th>Bogra</th>
      <td>229</td>
      <td>438</td>
      <td>-</td>
      <td>492</td>
      <td>325</td>
      <td>185</td>
      <td>356</td>
      <td>320</td>
      <td>381</td>
      <td>224</td>
      <td>422</td>
      <td>420</td>
      <td>158</td>
      <td>264</td>
      <td>106</td>
      <td>568</td>
      <td>575</td>
    </tr>
        <tr>
       <th>chittagong</th>
      <td>264</td>
      <td>541</td>
      <td>492</td>
      <td>-</td>
      <td>167</td>
      <td>678</td>
      <td>409</td>
      <td>538</td>
      <td>599</td>
      <td>541</td>
      <td>575</td>
      <td>151</td>
      <td>425</td>
      <td>534</td>
      <td>599</td>
      <td>76</td>
      <td>425</td>
    </tr>
        <tr>
      <th>Comilla</th>
      <td>97</td>
      <td>373</td>
      <td>325</td>
      <td>167</td>
      <td>-</td>
      <td>510</td>
      <td>241</td>
      <td>370</td>
      <td>431</td>
      <td>373</td>
      <td>290</td>
      <td>95</td>
      <td>257</td>
      <td>367</td>
      <td>431</td>
      <td>243</td>
      <td>275</td>
    </tr>
        <tr>
       <th>Dinajpur</th>
      <td>414</td>
      <td>673</td>
      <td>186</td>
      <td>678</td>
      <td>510</td>
      <td>-</td>
      <td>541</td>
      <td>549</td>
      <td>566</td>
      <td>409</td>
      <td>607</td>
      <td>605</td>
      <td>343</td>
      <td>449</td>
      <td>79</td>
      <td>753</td>
      <td>760</td>
    </tr>
        <tr>
       <th>Faridpur</th>
	  <td>145</td>
      <td>132</td>
      <td>356</td>
      <td>409</td>
      <td>241</td>
      <td>541</td>
      <td>-</td>
      <td>129</td>
      <td>190</td>
      <td>132</td>
      <td>338</td>
      <td>336</td>
      <td>198</td>
      <td>269</td>
      <td>462</td>
      <td>484</td>
      <td>491</td>
    </tr>
        <tr>
       <th>Jessore</th>
	  <td>274</td>
      <td>261</td>
      <td>320</td>
      <td>538</td>
      <td>370</td>
      <td>549</td>
      <td>129</td>
      <td>-</td>
      <td>61</td>
      <td>79</td>
      <td>467</td>
      <td>465</td>
      <td>163</td>
      <td>233</td>
      <td>426</td>
      <td>626</td>
      <td>632</td>
    </tr>
        <tr>
       <th>Khulna</th>
	  <td>335</td>
      <td>322</td>
      <td>361</td>
      <td>599</td>
      <td>431</td>
      <td>566</td>
      <td>190</td>
      <td>61</td>
      <td>-</td>
      <td>158</td>
      <td>528</td>
      <td>526</td>
      <td>226</td>
      <td>295</td>
      <td>488</td>
      <td>687</td>
      <td>694</td>
    </tr>
        <tr>
       <th>Kushtia</th>
	  <td>277</td>
      <td>264</td>
      <td>224</td>
      <td>541</td>
      <td>373</td>
      <td>409</td>
      <td>132</td>
      <td>79</td>
      <td>158</td>
      <td>-</td>
      <td>470</td>
      <td>468</td>
      <td>66</td>
      <td>137</td>
      <td>330</td>
      <td>616</td>
      <td>623</td>
    </tr>
        <tr>
       <th>Mymensing</th>
	  <td>193</td>
      <td>470</td>
      <td>422</td>
      <td>457</td>
      <td>290</td>
      <td>607</td>
      <td>338</td>
      <td>467</td>
      <td>528</td>
      <td>470</td>
      <td>-</td>
      <td>385</td>
      <td>356</td>
      <td>464</td>
      <td>528</td>
      <td>533</td>
      <td>539</td>
    </tr>
        <tr>
       <th>Noakhali</th>
	   <td>192</td>
      <td>468</td>
      <td>420</td>
      <td>151</td>
      <td>95</td>
      <td>605</td>
      <td>336</td>
      <td>465</td>
      <td>526</td>
      <td>468</td>
      <td>385</td>
      <td>-</td>
      <td>352</td>
      <td>462</td>
      <td>526</td>
      <td>235</td>
      <td>352</td>
    </tr>
        <tr>
       <th>Pabna</th>
	  <td>161</td>
      <td>280</td>
      <td>158</td>
      <td>425</td>
      <td>257</td>
      <td>343</td>
      <td>198</td>
      <td>163</td>
      <td>224</td>
      <td>66</td>
      <td>354</td>
      <td>352</td>
      <td>-</td>
      <td>109</td>
      <td>264</td>
      <td>500</td>
      <td>507</td>
    </tr>
        <tr>
       <th>Rajshahi</th>
	  <td>270</td>
      <td>401</td>
      <td>264</td>
      <td>534</td>
      <td>367</td>
      <td>449</td>
      <td>268</td>
      <td>233</td>
      <td>295</td>
      <td>137</td>
      <td>464</td>
      <td>463</td>
      <td>109</td>
      <td>-</td>
      <td>370</td>
      <td>610</td>
      <td>616</td>
    </tr>
        <tr>
       <th>Rangpur</th>
	  <td>335</td>
      <td>594</td>
      <td>206</td>
      <td>599</td>
      <td>431</td>
      <td>79</td>
      <td>462</td>
      <td>426</td>
      <td>488</td>
      <td>330</td>
      <td>528</td>
      <td>526</td>
      <td>264</td>
      <td>370</td>
      <td>-</td>
      <td>675</td>
      <td>681</td>
    </tr>
        <tr>
       <th>Rangamati</th>
	  <td>340</td>
      <td>616</td>
      <td>568</td>
      <td>76</td>
      <td>243</td>
      <td>753</td>
      <td>484</td>
      <td>626</td>
      <td>687</td>
      <td>616</td>
      <td>533</td>
      <td>235</td>
      <td>500</td>
      <td>610</td>
      <td>675</td>
      <td>-</td>
      <td>681</td>
    </tr>
        <tr>
       <th>sylhet</th>
	  <td>346</td>
      <td>623</td>
      <td>575</td>
      <td>425</td>
      <td>257</td>
      <td>760</td>
      <td>491</td>
      <td>632</td>
	  <td>694</td>
      <td>623</td>
      <td>539</td>
      <td>352</td>
      <td>507</td>
      <td>616</td>
      <td>681</td>
      <td>500</td>
      <td>-</td>
          </tr>

    
  </tbody>
  

</table>




	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
