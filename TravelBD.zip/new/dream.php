<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="distance.php">Distance chart</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                             <h1>Dream Destination</h1>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left" bgcolor="#FFFFFF"> 
							<hr color="#1084C0" size="1" width="80%" align="center">
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> 
							<table name="box" border="0" width="100%" bgcolor="#ffffff" cellspacing="1">
							<tr> 
                            <td width="100%" bgcolor="#FFFFFF"> 
								<p align="center">
								<map name="FPMap1"> 
                                  <area href="dream_dest_coxsbazar.php" shape="rect" coords="37, 24, 172, 69">
                                  <area href="dream_dest_sylhet.php" shape="rect" coords="288, 47, 420, 91">
                                  <area href="dream_dest_sundarban.php" shape="rect" coords="35, 120, 155, 136">
                                  <area href="dream_dest_kuakata.php" shape="rect" coords="321, 137, 422, 155">
                                  <area href="dream_dest_hill_tracks.php" shape="rect" coords="38, 178, 178, 219">
                                  <area href="dream_dest_dhaka.php" shape="rect" coords="335, 188, 423, 207">
                                  <area href="dream_dest_archaeological_site.php" shape="rect" coords="34, 252, 216, 273">
                                  <area href="dream_dest_rajshahi.php" shape="rect" coords="33, 298, 137, 319">
                                  <area href="dream_dest_chittagong.php" shape="rect" coords="307, 244, 424, 260">
                                  <area href="dream_dest_islamic_heritage.php" shape="rect" coords="277, 301, 424, 318">
                                </map>
                                <img border="0" src="montage_dream_destination.jpg" usemap="#FPMap1" width="455" height="337"> 
                            </td>
							</tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>
							</td>
							</tr>
							</table>
                           

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>