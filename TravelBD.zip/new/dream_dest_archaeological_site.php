<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style4.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								Bangladesh 
                                is a country considerably rich in archaeological 
                                wealth, especially of the medieval period both 
                                during the Muslim and pre-Muslim rules, though 
                                most of it is still unexplored and unknown. In 
                                archaeological fieldwork and research this area 
                                was very much neglected for a long time for various 
                                reasons, not the least of which are its difficult 
                                geography and climate and remoteness from the 
                                main centers of the subcontinent.<br>
                                <br>
                                &nbsp;With the independence of Bangladesh in 1971 
                                the Government has undertaken a number of field 
                                projects including a comprehensive survey and 
                                exploration of the hitherto unexplored areas and 
                                a fairly ambitious scheme of excavations on selected 
                                sites.&nbsp;<br>
                                <br>
                                Though work at present is carried out on a limited 
                                scale, the discoveries already made have been 
                                significant, while new information and fresh evidence 
                                are coming out gradually. These fresh explorations 
                                are likely to add substantially to our knowledge 
                                of the history and chronology of ancient Bangladesh 
                                and various aspects of her life and culture.&nbsp;<br>
                                <br>
                                The earlier history of Bangladesh reveals that 
                                Buddhism received royal patronage from some important 
                                ruling dynasties like the great Pala rulers, the 
                                Chandras and the Deva Kings. Under their royal 
                                patronage numerous well-organized, self-contained 
                                monasteries sprang up all over the country. The 
                                major archaeological sites are described below.<br>
                                <br>
                                <font color="#008000">Paharpur - Largest Buddhist 
                                Seat of learning:&nbsp; </font><br>
                                <br>
                                Paharpur is a small village 5 km. west of Jamalganj 
                                in the greater Rajshahi district where the remains 
                                of the most important and the largest known monastery 
                                south of the Himalayas has been excavated. This 
                                7th century archaeological find covers approximately 
                                an area of 27acres of land. The entire establishment, 
                                occupying a quadrangular court, measuring more 
                                than 900 ft. externally on each side, has high 
                                enclosure- walls about 16 ft. in thickness and 
                                from 12 ft. to 15 ft. height. With elaborate gateway 
                                complex on the north, there are 45 cells on the 
                                north and 44 in each of the other three sides 
                                with a total number of 177 rooms. The architecture 
                                of the pyramidal cruciform temple is profoundly 
                                influenced by those of South-East Asia, especially 
                                Myanmar and Java.<br>
                                <br>
                                A small site-Museum built in 1956-57 houses the 
                                representative collection of objects recovered 
                                from the area.The excavated findings have also 
                                been preserved at theVarendra Research Museum 
                                at Rajshahi.The antiquities of the museum include 
                                terracotta plaques, images of different gods and 
                                goddesses, potteries, coins, inscriptions, ornamental 
                                bricks and other minor clay objects.<br>
                                <br>
                                <font color="#008000">Mahasthangarh-The oldest 
                                archaeological site</font><br>
                                <br>
                                The oldest archaeological site of Bangladesh is 
                                on the western bank of river Karatoa 18 km. north 
                                of Bogra town beside Bogra-Rangpur Road. The spectacular 
                                site is an imposing landmark in the area having 
                                a fortified, oblong enclosure measuring 5000 ft. 
                                by 4500 ft.with an average height of 15 ft. from 
                                the surrounding paddy fields. Beyond the fortified 
                                area, other ancient ruins fan out within a semicircle 
                                of about five miles radius. Several isolated mounds, 
                                the local names of which are Govinda Bhita Temple, 
                                Khodai Pathar Mound, Mankalir Kunda, Parasuramer 
                                Bedi, Jiyat Kunda etc. surround the fortified 
                                city.<br>
                                <br>
                                This 3rd century archaeological site is still 
                                held to be of great sanctity by the Hindus. Every 
                                year (rnid-April) and once in every 12 years (December) 
                                thousands of Hindu devotees join the bathing ceremony 
                                on the bank of river Karatoa. A visit to the Mahasthangarh 
                                site museum will open up for you wide variety 
                                of antiquities, ranging from terracotta objects 
                                to gold ornaments and coins recovered from the 
                                site.<br>
                                <br>
                                For visiting Paharpur and Mahasthangarh, the visitors 
                                may enjoy the hospitality of Parjatan Motel at 
                                Bogra. Mahasthangarh and Paharpur are only 18 
                                km. and 75 km.respectively from Bogra town.<br>
                                Rajshahi is famous for pure silk. Silk processing 
                                industry of the Sericulture Board is just ten 
                                minutes walk from Parjatan Motel at Rajshahi. 
                                Besides the Sericulture Board, a visit to Varendra 
                                Research Museum at the heart of the City for archaeological 
                                finds, would be most rewarding.<br>
                                Maimamati&nbsp;<br>
                                <br>
                                An isolated low, dimpled range of hills, dotted 
                                -with more than 50 ancient Buddhist settlements 
                                of the 8th to 12th century A.D. known as Mainamati-Laimai 
                                range are extended through the centre of the district 
                                of Comilla.<br>
                                <br>
                                Salban Vihara, almost in the middle of the Mainarnati-Lalmai 
                                hill range consists of 115 cells, built around 
                                a spacious courtyard with cruciform temple in 
                                the centre facing its only gateway complex to 
                                the north resembling that of the Paharpur Monastery.<br>
                                <br>
                                Kotila Mura situated on a flattened hillock, about 
                                5 km north of Salban Vihara inside the Comilla 
                                Cantonment is a picturesque Buddhist establishment. 
                                Here three stupas are found side by side representing 
                                the Buddhist &quot;Trinity&quot; or three jewels 
                                i.e. the Buddha, Dharma and Sangha.<br>
                                <br>
                                Charpatra Mura is an isolated small oblong shrine 
                                situated about 2.5 krn. north-west of kotila Mura 
                                stupas. The only approach to the shrine is from 
                                the East through a gateway which leads to a spacious 
                                hall.<br>
                                <br>
                                The Mainamati site Museum has a rich and varied 
                                collection of copper plates, gold and silver coins 
                                and 86 bronze objects. Over 150 bronze statues 
                                have been recovered mostly from the monastic cells, 
                                bronze stupas, stone sculptures and hundreds of 
                                terracotta plaques each measuring on an average 
                                of 9&quot; high and 8&quot; to 12&quot; wide. 
                                Mairiamati is only 114 km. from Dhaka City and 
                                is just a day's trip by road on way to Chittagong.<br>
                                <br>
                                <font color="#008000">Lalbagh Fort:</font></font> 
                                <font face="Verdana, Arial, Helvetica, sans-serif" size="2">&nbsp;<br>
                                <br>
                                The capital city Dhaka predominantly was a city 
                                of the Mughals. In hundred years of their vigorous 
                                rule successive Governors and princely Viceroys 
                                who ruled the province, adorned it with many noble 
                                monuments in the shape of magnificent places, 
                                mosques, tombs, fortifications and 'Katras' often 
                                surrounded with beautifully laid out gardens and 
                                pavilions. Among these, few have survived the 
                                ravages of time, aggressive tropical climate of 
                                the land and vandal hands of man.<br>
                                But the finest specimen of this period is the 
                                Aurangabad Fort, commonly known as Lalbagh Fort, 
                                which, indeed represents the unfulfilled dream 
                                of a Mughal Prince.&nbsp;<br>
                                <br>
                                It occupies the south western part of the old 
                                city, overlooking the Buriganga on whose northern 
                                bank it stands as a silent sentinel of the old 
                                city. Rectangular in plan, it encloses an area 
                                of 1082' by 800' and in addition to its graceful 
                                lofty gateways on south-east and north-east corners 
                                and a subsidiary small unpretentious gateway on 
                                north, it also contians within its fortified perimeter 
                                a number of splendid monuments, surrounded by 
                                attractive garden.&nbsp;<br>
                                <br>
                                These are, a small 3-domed mosque, the mausoleum 
                                of Bibi Pari the reputed daughter of Nawab Shaista 
                                Khan and the Hammam and Audience Hall of the Governor. 
                                The main purpose of this fort, was to provide 
                                a defensive enclosure of the palacial edifices 
                                of the interior and as such was a type of palace-fortress 
                                rather than a seige fort.<br>
                                <br>
                                <font color="#008000">Sonargaon:&nbsp;<br>
                                <br>
                                </font>About 27 km. from Dhaka, Sonargaon is one 
                                of the oldest capitals of Bengal. It was the seat 
                                of Deva Dynasty until the 13th century. From then 
                                onward till the advent of the Mughals, Sonargaon 
                                was subsidiary capital of the Sultanate of Bengal. 
                                Among the ancient monuments still intact are the 
                                Tomb of Sultan Ghiasuddin (1399-1409 A. D), the 
                                shrines of Panjpirs and Shah Abdul Alia and a 
                                beautiful mosque in Goaldi villaae.<br>
                                <br>
                                <font color="#008000">Shatt-Gumbad Mosque:&nbsp;<br>
                                <br>
                                </font>In mid-15th century, a Muslim colony was 
                                founded in the inhospitable mangrove forest of 
                                the Sundarbans near the sea coast in the Bagerhat 
                                district by an obscure saint-General, named Ulugh 
                                Khan Jahan. He was the earliest torch bearer of 
                                islam in the South who laid the nucleus of an 
                                affluent city during the reign of Sultan Nasiruddin 
                                Mahmud Shah (1442-59), then known as 'khalifatabad' 
                                (present Bagerhat).&nbsp;<br>
                                <br>
                                Khan Jahan adorned his city with numberous mosques, 
                                tanks, roads and other public buildings, the spectacular 
                                ruins of which are focused around the most imposing 
                                and largest multidomed mosques in Bangladesh, 
                                known as the Shait-Gumbuj Masjid (160'xlO8'). 
                                The stately fabric of the monument, serene and 
                                imposing, stands on the eastern bank of an unusually 
                                vast sweet-water tank,clustered around by the 
                                heavy foliage of a low-laying countryside, characteristic 
                                of a sea-coast landscape.<br>
                                <br>
                                The mosque roofed over with 77 squat domes, including 
                                7 chauchala or four-sided Pitched Bengali domes 
                                in the middle row. The vast prayer hall, although 
                                provided with 11arched doorways on east and 7 
                                each on north and south for ventilation and light, 
                                presents a dark and sombre appearance inside. 
                                It is divided into 7 longitudinal aisles and 11 
                                deep days by a forest of slender stone columns, 
                                from which springs rows of endless arches, supporting 
                                the domes. Six feet thick, slightly tapering walls 
                                and hollow and round, almost detached corner towers, 
                                resembling the bastions of fortress, each capped 
                                by small rounded cupolas, recall the Tughlaq architecture 
                                of Delhi. The general appearance of this noble 
                                monument with its stark simplicity but massive 
                                character reflects the strongth and simplicity 
                                of the builder.<br>
                                <br>
                                <font color="#008000">Kantanagar Temple:&nbsp;<br>
                                <br>
                                </font>The most ornate among the late medieval 
                                temples of Bangladesh is the Kantanagar temple 
                                near Dinajpur town, which was built in 1752 by 
                                Maharaja Pran Nath of Dinajpur. The temple, a 
                                50' square three storyed edifice, rests on a slightly 
                                curved raised plinth of sandstone blocks, believed 
                                to have been quarried from the ruins of the ancient 
                                city of Bangarh near Gangharampur in West Bengal. 
                                It was originally a navaratna temple, crowned 
                                with four richly ornamental corner towers on two 
                                storeys and a central one over the third storey.&nbsp;<br>
                                <br>
                                Unfortunately these ornate towers collapsed during 
                                an earthquake at the end of the 19th century. 
                                ln spite of this, the monument rightly claims 
                                to bethe finest extant example of its type in 
                                brick and terracotta,built by bengali artisans. 
                                The central cells is surrounded on all sides by 
                                a covered varendah, each pierced by three entrances, 
                                which are separated by equally ornate dwarf brick 
                                pillars, Corresponding to the three delicately 
                                causped entrances of the balcony, the sanctum 
                                has also three richly decorated arched openings 
                                on each face.&nbsp;<br>
                                <br>
                                Every inch of the temple surface is beautifully 
                                embellished with exquisite terracotta plaques, 
                                representing flora fauna, geometric motifs, mythological 
                                scenes and an astonishing array of contemporary 
                                social scenes and favourite pastimes.<br>
                                <br>
                                Besides, there are many other monuments which 
                                incite tourist interest.<br>
                                <br>
                                <font color="#008000">Ahsan Manzil:<br>
                                <br>
                                </font>On the bank of river Buriganga in Dhaka 
                                the Pink majestic Ahsan Manzil has been renovated 
                                and turned into a museum recently. It is an epitome 
                                of the nation's rich cultural heritage. It is 
                                the home of Nawab of Dhaka and a silent spectator 
                                to many events.<br>
                                Today's renovated Ahsan Manzil a monument of immense 
                                historical beauty. It has 31 rooms with a huge 
                                dome atop which can be seen from miles around. 
                                It now has 23 galleries in 31 rooms displaying 
                                of traits, furniture and household articles and 
                                utensils used by the Nawab.</font></font> 
								
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>