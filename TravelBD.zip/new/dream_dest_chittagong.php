<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style4.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								Chittagong, 
                                the second largest city of Bangladesh and a busy 
                                international seaport, is an ideal vacation spot. 
                                Its green hills and forests, its broad sandy beaches 
                                and its fine cool climate always attract the holiday-markers. 
                                Described by the Chinese traveler poet, Huen Tsang 
                                (7th century A.D) as &quot;a sleeping beauty emerging 
                                from mists and water&quot; and given the title 
                                of &quot;Porto Grande&quot; by the 16th century 
                                Portuguese seafarers. Chittagong combines remains 
                                true to both the descriptions even today. It combines 
                                the busy hum of an active seaport with the shooting 
                                quiet of a charming hill town.<br>
                                <br>
                                The Shahi Jama-e-Masjid and Qadam Mubarak Mosque 
                                are two of the most impressive buildings in the 
                                city. It's also worth visiting the Ethnological 
                                Museum in the Modern City which has interesting 
                                displays on Bangladesh's tribal peoples. There 
                                are good views and cooling breezes from Fairy 
                                Hill in the British City in the north-western 
                                sector of the city.<br>
                                Chittagong is the country's chief port and is 
                                the main site for the establishment of heavy, 
                                medium and light industries. Bangladesh's only 
                                steel mill and oil refinery are also located in 
                                Chittagong.&nbsp;<br>
                                <br>
                                </font><font color="#008000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Language 
                                : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Bangla, 
                                English is spoken and understood.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Wearing 
                                Apparel : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Tropical 
                                in summer and light woolen in winter.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Communication 
                                &amp; Transport :</font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#3C911B"> 
                                </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Chittagong 
                                is connected by road and rail with rest of the 
                                country. Air link is available with Dhaka and 
                                Calcutta.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Car 
                                Rental : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Rent-A-Car 
                                facilities are available for city sightseeing 
                                and trips to Rangamati, Cox's Bazar, Sitakunda 
                                and other touristically important places.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Hill 
                                Districts : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                Hill Tracts is divided into three districts, namely 
                                Rangamati, Khagrachari and Bandarban.&nbsp;<br>
                                From Chittagong a 77 km. road amidst green fields 
                                and winding hills will take you to Rangamati, 
                                the headquarters of the Rangamati Hill District 
                                which is a wonderful repository of scenic splendours 
                                with flora and fauna of varied descriptions. It 
                                is also connected by water way from Kaptai.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#808080"><b>N.B</b></font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                                For visit of foreign tourists to the Hill Districts 
                                prior permission from the Government is required 
                                which can be arranged through Tour Operators &amp; 
                                BPC.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">The 
                                Hills :</font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#3C911B"> 
                                </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                Hill Tract is divided into four valleys surrounded 
                                by the Feni, Karnaphuli, Sangu (Sankhu) and Matamuhuri 
                                rivers and their tributaries. The ranges or hills 
                                of the Hill Tracts rise steeply thus looking far 
                                more impressive than what their height would imply 
                                and extend in long narrow ridges. The highest 
                                peaks on the northern side are Thangnang, Langliang 
                                and Khantiang while those on the southern side 
                                are Ramu, Taung, Keekradang, Tahjindong (4632 
                                ft, highest in Bangladesh), Mowdok Mual, Rang 
                                Tlang and Mowdok Tlang.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">The 
                                forests : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                valleys of the Hill Tracts are covered with thick 
                                planted forests. The vegetation in semi-evergreen 
                                to tropical evergreen dominated by tall teak trees. 
                                The natural vegetation can be seen best in the 
                                Rain-khyong valleys of the Bandarban district. 
                                This district provides the country with valuable 
                                wood used for various purposes, besides supplying 
                                wood and bamboo for the Karnaphuli Paper Mills 
                                and the Rayon Mills situated at Chandraghona. 
                                Here a tourist may be lucky to see how huge logs 
                                of wood are being carried to the plain by the 
                                tamed elephants.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Climate 
                                : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">There 
                                are there main seasons, the dry season (November 
                                to March), which is relatively cool, sunny and 
                                dry, the premonsoon season (April and May), which 
                                is very hot and sunny with occasional shower, 
                                and the rainy season (June to October), which 
                                is warm, cloudy and wet.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Tribal 
                                life :</font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#3C911B"> 
                                </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                inhabitants of the Hill Tracts are mostly tribal. 
                                Life of the tribal people is extremely fascinating. 
                                Majority of them are Buddhists and the rest are 
                                Hindus, Christians and Animists. Despite the bondage 
                                of religion, elements of primitiveness is strongly 
                                displayed in their rites, rituals and everyday 
                                life. The tribal families are matriarchal. The 
                                women-folk are more hardworking than the males 
                                and they are the main productive force.&nbsp;<br>
                                <br>
                                The tribal people are extremely self-reliant, 
                                they grow their own food, their girls weave their 
                                own clothes and generally speaking, they live 
                                a simple life. Each tribe has its own dialect, 
                                distinctive dress and rites and rituals. The common 
                                feature is their way of life which still speak 
                                of their main occupation. Some of them take pride 
                                in hunting with bows and arrows. Tribal women 
                                are very skilful in making beautiful handicrafts. 
                                Tribal people are generally peace loving, honest 
                                and hospitable. They usually greet a tourist with 
                                a smile.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#3C911B"><br>
                                </font><font color="#008000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Other 
                                Tourist Attractions &gt;&gt;</font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2"><br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Tomb 
                                of Sultan Bayazid Bostami : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Situated 
                                on a hillock at Nasirabad, about 6 km. to the 
                                north-west of Chittagong town, this shrine attracts 
                                a large number of visitors and pilgrims. At its 
                                base is a large tank with several hundred tortoises. 
                                Tradition has it that these animals are the descendants 
                                of the evil spirits (genii) who were cast into 
                                this shape because they incurred the wrath of 
                                the great saint who visited the place about 1100 
                                years age.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">World 
                                War II Cemetery : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">In 
                                a well-preserved cemetery at a quiet and picturesque 
                                place within the city lie buried in eternal peace 
                                over 700 soldiers from British, Australia, Canada, 
                                New Zealand, India, Myanmar, East and West Africa, 
                                The Netherlands and Japan who laid down their 
                                lives on the Myanmar front during the World War 
                                II.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Shrine 
                                of Shah Amanat : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                Shrine of Shah Amanat is another place of religious 
                                attraction, located in the heart of the town, 
                                the shrine is visited by hundreds of people everyday 
                                who pay homage to the memory of the saint.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Court 
                                Building Museum : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Situated 
                                on the Fairy Hill, this building commands a panoramic 
                                bird's eye view of Chittagong. This had been the 
                                scene of intense activity during the independence 
                                War in 1971. A museum has been established here<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Foy's 
                                Lake(Pahartali Lake) :</font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#3C911B"> 
                                </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Set 
                                amidst picturesque surroundings in the railway 
                                township of Pahartali 8 km. from Chittagong this 
                                is an ideal spot of outing and picnic thronged 
                                by thousands of visitors every week.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Mercantile 
                                Marine Academy at Juldia : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                only training institute of its kind in Bangladesh, 
                                situated on the month of the river Karnaphuli.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Patenga 
                                and Fouzdarhat Sea Beaches :</font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#3C911B"> 
                                </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Patenga 
                                beach is about 22 km. from Chittagong and is approachable 
                                by a motorable road. On the way to the beach one 
                                passes the Patenga Airport. Another ideal picnic 
                                spot is the Fouzdarhat sea-beach about 16 km. 
                                from Chittagong.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Port 
                                Area : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Located 
                                near the river mouth of the river Karnaphuli, 
                                the Chittagong port has a recorded history from 
                                9th century. Today, this is the principal seaport 
                                of the country&nbsp;<br>
                                <br>
                                </font><font color="#008000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Ethnological 
                                Museum : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">This 
                                museum located in Agrabad is a treasure-house 
                                of a variety of tribal culture and heritage of 
                                Bangladesh<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Zia 
                                Museum : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                                government Circuit House where former president 
                                Ziaur Rahman was assasinated has been turned into 
                                a museum.<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Sitakunda 
                                : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">About 
                                37 km. from Chittagong lies an interesting place 
                                known as Sitakunda, served by a railway station 
                                of the same name. Famous among the many temples 
                                in this place are the Chandranath Temple and the 
                                Buddhist Temple has a footprint of Lord Buddha. 
                                These places particularly the hilltops are regarded 
                                as very sacred by the Buddhists and the Hindus. 
                                Siva-chaturdashi festival is held every year in 
                                February when thousands of pilgrims assemble for 
                                the celebrations which last about ten days. There 
                                is a salt water spring 5 km. to the north of Sitakunda, 
                                known as Labanakhya.&nbsp;<br>
                                <br>
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#008000">Chandraghona 
                                : </font><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="2">Forty-eight 
                                kilometer from Chittagong, on the Kaptai Road 
                                is Chandraghona where one of the biggest paper 
                                mills in Asia is located. Close to the paper mill 
                                there is a rayon factory which produces synthetic 
                                fibers from bamboo.&nbsp;</font></font> 
								
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>