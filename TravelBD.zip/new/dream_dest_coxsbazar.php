<?php
	include 'config.php';
	
?>

<html>
<head><title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style3.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>


</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">Miles 
                                of golden sands, towering cliffs, surfing waves, 
                                rare conch shells, colorful pagodas, Buddhist 
                                temples and tribes, delightful sea-food--this 
                                is Cox's Bazar, the tourist capital of Bangladesh. 
                                Having the world's longest (120 kilometers.) beach 
                                sloping gently down to the blue waters of the 
                                Bay of Bengal, Cox's Bazar is one of the most 
                                attractive tourist sport in the country.&nbsp;<br>
                                <br>
                                There are also a few very old wooden Buddhist 
                                temples at Ramu, a few kilometers from Cox's Bazar, 
                                well worth visiting.<br>
                                <br>
                                Located at a distance of 152 km. south of Chittagong, 
                                the leading seaport of Bangladesh, Cox's Bazar 
                                is connected both by air and road from Dhaka and 
                                Chittagong.<br>
                                <br>
                                A drive to Teknaf, which is the southernmost tip 
                                of the mainland of Bangladesh, is a memorable 
                                journey. A day trip to either Moheshkhali or Sonadia, 
                                the deltaic islands nestled among the gentle waves 
                                of the Bay of Bengal, will also be really interesting.<br>
                                <br>
                                Other attractions for visitors are conch shell 
                                market, tribal handicraft, salt and prawn cultivation.<br>
                                <br>
                                Besides, the longest sea-beach, Cox's Bazar and 
                                its adjoin areas have a lot of things to see and 
                                places deserve visit by the tourists.<br>
                                <br>
                                <font color="#008000">Himchari:</font> It is about 
                                32 km. South of Cox's Bazar along the beach, a 
                                nice place for picnic and shooting. The famous 
                                &quot;Broken Hills&quot; and waterfalls here are 
                                rare sights.<br>
                                <br>
                                <font color="#008000">Inani:</font> It is about 
                                32 km. South of Cox's Bazar and just on the beach, 
                                with the sea to the west and a background of steep 
                                hills to the east. Inani casts a magic spell on 
                                those who step into that dreamland. It is only 
                                half an hour's drive from Cox's Bazar and an ideal 
                                place for Sea-bathing and picnic.<br>
                                <br>
                                <font color="#008000">Maheskhali:</font> An island 
                                off the coast of Cox's Bazar. It has an area of 
                                268 square kilometers. Through the centre of the 
                                island and along the eastern coast line rises 
                                a range of low hills, 300 feet high; but the coast 
                                to the west and north is a lowlying treat, fringed 
                                by mangrove jungle. In the hills on the coast 
                                is built the shrine of Adinath, dedicated to siva. 
                                By its side on the same hill is Buddhist Pagoda.<br>
                                <br>
                                <font color="#008000">Ramu: </font>This is a typical 
                                Buddhist village, about 16 km. from Cox's Bazar, 
                                on the main road to Chittagong. There are monasteries, 
                                khyangs and pagodas containing images of Buddha 
                                in gold, bronze and other metals inilaid with 
                                precious stones.<br>
                                <br>
                                One of the most interesting of these temples is 
                                on the bank of the Baghkhali river. It houses 
                                not only interesting relics and Burmes handicrafts 
                                but also a large bronze statue of Buddha measuring 
                                thirteen feet high and rests on a six feet high 
                                pedestal. The wood carving of this khyang is very 
                                delicate and refined.<br>
                                <br>
                                The village has a charm of its own. Weavers ply 
                                there trade in open workshops and craftsmen make 
                                handmade cigars in their pagoda like houses.<br>
                                <br>
                                <font color="#008000">Sonadia Island: </font>It 
                                is about seven kilometer of Cox's Bazar and about 
                                nine square kilometer in area. The western side 
                                of the island is sandy and different kinds of 
                                shells are found on the beach. Off the northern 
                                part of the island, there are beds of window pane 
                                oysters. During winter, fisherman set up temporary 
                                camps on the island and dry their catches of sea 
                                fish.<br>
                                <br>
                                <font color="#008000">St. Martins Island: </font>This 
                                small coral island about 10km (6mi) south-west 
                                of the southern tip of the mainland is a tropical 
                                cliché, with beaches fringed with coconut palms 
                                and bountiful marine life. There''s nothing more 
                                strenuous to do here than soak up the rays, but 
                                it''s a clean and peaceful place without even 
                                a mosquito to disrupt your serenity.<br>
                                <br>
                                &nbsp;It''s possible to walk around the island 
                                in a day because it measures only 8 sq km (3 sq 
                                mi), shrinking to about 5 sq km (2 sq mi) during 
                                high tide. Most of island''s 5500 inhabitants 
                                live primarily from fishing, and between October 
                                and April fisher people from neighbouring areas 
                                bring their catch to the island''s temporary wholesale 
                                market. A ferry leaves Teknaf for St Martin every 
                                day and takes around 3 hours.<br>
                                <br>
                                Getting to St. Martin''s is a three-step program. 
                                First you''ll need to fly or bus it down to Cox''s 
                                Bazar, and then catch a bus to Teknaf, which is 
                                right on the very tip of Bangladesh, sandwiched 
                                up against Myanmar. From Teknar, ferries run daily 
                                to St. Martin Island. The total distance from 
                                Dhaka to the island is 510km (316mi).<br>
                                <br>
                                <font color="#008000">The Aggameda Khyang, Cox's 
                                Bazar:&nbsp;<br>
                                </font><br>
                                Equally elaborate in plan, elevation and decoration 
                                is the Aggameda Khyang near the entrance to the 
                                Cox's Bazar town which nestles at the foot of 
                                a hill under heavy cover of a stand of large trees. 
                                The main sanctuary-cum-monastery is carried on 
                                a series of round timber columns, which apart 
                                from accommodating the prayer chamber and an assembly 
                                hall, also is the repository of a large of small 
                                bronze Buddha images-mostly of Burmese origin-- 
                                and some old manuscripts.&nbsp;<br>
                                <br>
                                Beyond the main khyang to the south there is an 
                                elevated wooden pavilion and a smaller brick temple 
                                with a timber and corrugated metal root. Apart 
                                from bearing an inscription in Burmese over its 
                                entrance the temple contains some large stucco 
                                and bronze Buddha images.<br>
                                <br>
                                <font color="#008000">Teknaf:</font> Southernmost 
                                tip of Bangladesh, Teknaf situated on the Naaf 
                                river and just at the end of the hilly regions 
                                of the district. Mayanmar is on the opposite bank 
                                of Naaf river. Wild animals and birds are available 
                                but the most interesting thing is a journey on 
                                the river. Wide sandy beach in the backdrop of 
                                high hills with green forests is an enchanting 
                                scene never to be forgotten.<br>
                                <br>
                                The Cox's Bazar Holiday Complex of Bangladesh 
                                Parjatan Corporation, the National Tourism Organization 
                                is an ideal tourist resort having a number of 
                                facilities for the visitors.</font></font> 
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>