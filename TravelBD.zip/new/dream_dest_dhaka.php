<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style4.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								
								Dhaka 
                                has several hundred mosques. Prominent are Baitull 
                                Mukarram-National Mosque, the seven Domed Mosque 
                                (17th century), Star Mosque (18th century) , Chawkbazar 
                                Mosque and Huseni Dalan Mosque.&nbsp;<br>
                                <br>
                                <font color="#008000">Hindu Temples : </font>Dhakeshwari 
                                Temple (11th Century), Ramkrishna Mission.&nbsp;<br>
                                <br>
                                <font color="#3C911B">Churches :</font> Armenian 
                                Church (1781 A.D.) St. Mary's Cathedral at Ramna, 
                                Church of Bangladesh or former Holy Rosary Church 
                                (1677A.D.) at Tejgaon.&nbsp;<br>
                                <br>
                                <font color="#008000">National Memorial : </font>It 
                                locates at Savar, 35, km. from Dhaka city. The 
                                memorial designed by architect Moinul Hossain 
                                is dedicated to the sacred memory of the millions 
                                of unknown martyrs of the war of liberation.&nbsp;<br>
                                <br>
                                <font color="#008000">Lalbagh Fort : </font>It 
                                was built in 1678 A.D. by Prince Mohammad Azam, 
                                son of Mughal emperor Aurangazeb. The fort was 
                                the scene of bloody battle during the first war 
                                of independence (1857) when 260 sepoys stationed 
                                here backed by the people revolted against British 
                                forces. Outstanding among the monuments of the 
                                Lalbagh are the tomb of Pari Bibi , Lalbagh Mosque, 
                                Audience Hall and Hammam of Nawab Shaista Khan 
                                now housing a museum.&nbsp;<br>
                                <br>
                                The capital city Dhaka predominantly was a city 
                                of the Mughals. In hundred years of their vigorous 
                                rule successive Governors and princely Viceroys 
                                who ruled the province, adorned it with many noble 
                                monuments in the shape of magnificent places, 
                                mosques, tombs, fortifications and 'Katras' often 
                                surrounded with beautifully laid out gardens and 
                                pavilions. Among these, few have survived the 
                                ravages of time, aggressive tropical climate of 
                                the land and vandal hands of man.<br>
                                <br>
                                But the finest specimen of this period is the 
                                Aurangabad Fort, commonly known as Lalbagh Fort, 
                                which, indeed represents the unfulfilled dream 
                                of a Mughal Prince. It occupies the south western 
                                part of the old city, overlooking the Buriganga 
                                on whose northern bank it stands as a silent sentinel 
                                of the old city. Rectangular in plan, it encloses 
                                an area of 1082' by 800' and in addition to its 
                                graceful lofty gateways on south-east and north-east 
                                corners and a subsidiary small unpretentious gateway 
                                on north, it also contians within its fortified 
                                perimeter a number of splendid monuments, surrounded 
                                by attractive garden. These are, a small 3-domed 
                                mosque, the mausoleum of Bibi Pari the reputed 
                                daughter of Nawab Shaista Khan and the Hammam 
                                and Audience Hall of the Governor. The main purpose 
                                of this fort, was to provide a defensive enclosure 
                                of the palacial edifices of the interior and as 
                                such was a type of palace-fortress rather than 
                                a seige fort.<br>
                                <br>
                                <br>
                                <font color="#008000">1857 Memorial : </font>( 
                                Bahadur Shah Park) Built to commemorate the martyrs 
                                of the first liberation war (1857-59) against 
                                British rule. It was here that the revolting sepoys 
                                and their civil compatriots were publicly hanged.&nbsp;<br>
                                <br>
                                <font color="#008000">Bangabandhu Memorial Museum 
                                : </font>The residence of the father of the nation 
                                Bangabandhu Sheikh Mujibur Rahman at Dhanmondi 
                                has been turned into a musuam. It contains rare 
                                collection of personal effects and photographs 
                                of his lifetime.<br>
                                <br>
                                <font color="#008000">Mukti Juddha Museum : </font>Situated 
                                at Segun Bagicha area of the city the museum contains 
                                rare photographs of Liberation war and items used 
                                by the freedom fighters during the period.&nbsp;<br>
                                <br>
                                <font color="#008000">Ahsan Manzil Museum : </font>On 
                                the bank of the river Buriganga in Dhaka the pink 
                                majestic Ahsan Manzil has been renovated and turned 
                                into a museum recently. It is an example of the 
                                nations rich cultural heritage. It was the home 
                                of the Nawab of Dhaka and a silent spectator to 
                                many events. The renovated Ahsan Manzil is a monument 
                                of immense historical beauty. It has 31 rooms 
                                with a huge dome atop which can be seen from miles 
                                around. It now has 23 galleries displaying portraits, 
                                furniture and household articles and utensils 
                                used by the Nawab.&nbsp;<br>
                                <br>
                                <font color="#008000">Curzon Hall : </font>Beautiful 
                                architectural building named after Lord Curzon. 
                                It now houses the Science Faculty of Dhaka University.&nbsp;<br>
                                <br>
                                <font color="#008000">Old High Court Building 
                                : </font>Originally built as the residence of 
                                the British Governor, it illustrates a happy blend 
                                of European and Mughal architecture.&nbsp;<br>
                                <br>
                                <font color="#008000">Dhaka Zoo : </font>Popularly 
                                known as Mirpur Zoo. Colorful and attractive collections 
                                of different local and foreign species of animals 
                                and birds including the majestic Royal Bengal 
                                Tiger are available here.&nbsp;<br>
                                <br>
                                <font color="#008000">National Museum : </font>Located 
                                at the central point of the city, the museum contains 
                                a large number of interesting collections including 
                                sculptures and paintings of the Hindu, Buddhist 
                                and Muslim periods.&nbsp;<br>
                                <br>
                                <font color="#008000">Botanical Garden :</font> 
                                Built on an area of 205 acres of land at Mirpur 
                                and adjacent to Dhaka Zoo. One can have a look 
                                at the zoo and the botanical garden in one trip.&nbsp;<br>
                                <br>
                                <font color="#008000">National Park : </font>Situated 
                                at Rejendrapur, 40 km. north of Dhaka city , this 
                                is a vast (1,600 acres) national recreational 
                                forest with facilities for picnic and rowing etc.&nbsp;<br>
                                <br>
                                <font color="#008000">Central Shahid Minar : </font>Symbol 
                                of Bengali nationalism. This monument was built 
                                to commemorate the martyrs of the historic Language 
                                movement of 1952. Hundreds and thousands of people 
                                with floral wreaths and bouquet gather on 21 February 
                                every year to pay respect in a solemn atmosphere. 
                                Celebrations begin at zero hour of midnight.&nbsp;<br>
                                <br>
                                <font color="#008000">National Poet's Graveyard 
                                : </font>Revolutionary poet Kazi Nazrul Islam 
                                died on the 29 August 1976 and was buried here. 
                                The graveyard is adjacent to the Dhaka University 
                                Mosque.&nbsp;<br>
                                <br>
                                <font color="#008000">Suhrawardy Uddyan (Garden) 
                                : </font>A Popular Park. The oath of independence 
                                of Bangladesh was taken here and Father of the 
                                Nation Bangabandhu Sheik Mujibur Rahman gave clarion 
                                call for independence on this occasion on the 
                                7th March 1971. The place is famous for its lush 
                                verdure and gentle breezes. Eternal Flame to enliven 
                                the memory of the martyrs of our Liberation war 
                                has been blown here recently.<br>
                                <br>
                                <font color="#008000">Mausoleum of National Leaders 
                                : </font>Located at the southwestern corner of 
                                Suhrawardy Uddyan, it is the eternal resting place 
                                of great national leaders, Sher-e-Bangla A.K. 
                                Fazlul Haque, Hossain Shahid Suhrawardy and Khaja 
                                Nazimuddin.&nbsp;<br>
                                <br>
                                <font color="#008000">Banga Bhaban : </font>The 
                                official residence of the President, located in 
                                the city . One can have an outside view of this 
                                grand palace.&nbsp;<br>
                                <br>
                                <font color="#008000">Baldha Garden : </font>Unique 
                                creation of the late Narendra Narayan Roy, the 
                                landlord of Baldha. Year of establishment was 
                                1904. Located in Wari area of Dhaka city, the 
                                garden with its rich collection of indigenous 
                                and exotic plants is one of the most exciting 
                                attraction for naturalists and tourists.&nbsp;<br>
                                <br>
                                <font color="#008000">Ramna Green :</font> A vast 
                                stretch of green garden surrounded by a serpentine 
                                lake near the Sheraton Hotel.&nbsp;<br>
                                <br>
                                <font color="#008000">Parliament House :</font> 
                                Jatiya Sangsad Bhaban (Parliament House) located 
                                at Sher-e-Bangla Nagar has distinctive architectural 
                                features. Designed by the famous architect Louis 
                                I. Kahn, it may be called an architectural wonder 
                                of this region.&nbsp;<br>
                                <br>
                                <font color="#008000">Science Museum : </font>The 
                                museum is a modern learning center related to 
                                the latest scientific discoveries. It is situated 
                                at Agargaon.&nbsp;<br>
                                <br>
                                <font color="#008000">Institute of Arts and Crafts 
                                :</font> Situated in the picturesque surroundings 
                                of Shahbagh the Institute of Arts and Crafts has 
                                a representative collection of folk-art and paintings 
                                by artists of Bangladesh.&nbsp;<br>
                                <br>
                                <font color="#008000">Sonargaon :</font> About 
                                29 km. from Dhaka. Sonargaon is one of the oldest 
                                capitals of Bangal. A Folk Arts and Crafts Museum 
                                has been established here.<br>
                                <br>
                                Other attractions in and around Dhaka include 
                                the Institute of Arts and Crafts with its representative 
                                collection of folk art and paintings, handicraft 
                                shops. Aparajeya Bangla monument, picnic spots 
                                at Chandra and Salna, industrial estates of Tongi, 
                                Narayanganj, Demara, Tejgaon, cruising by country 
                                boat in the nearby river or a visit to a village 
                                to see jute cultivation, weaving and pottery making. 
                                Last but not the least travel by a horse driven 
                                cart or rickshaw along busy Dhaka streets is a 
                                rewarding experience.<br>
                                <br>
                                <br>
                                About 27 km. from Dhaka, Sonargaon is one of the 
                                oldest capitals of Bengal. It was the seat of 
                                Deva Dynasty until the 13th century. From then 
                                onward till the advent of the Mughals, Sonargaon 
                                was subsidiary capital of the Sultanate of Bengal. 
                                Among the ancient monuments still intact are the 
                                Tomb of Sultan Ghiasuddin (1399-1409 A. D), the 
                                shrines of Panjpirs and Shah Abdul Alia and a 
                                beautiful mosque in Goaldi villaae.<br>
                                <br>
                                <font color="#008000">Picnic Spots : </font>There 
                                are good picnic spots in the area around Savar 
                                and Mirzapur. Other beauty spots connected by 
                                road with Dhaka include Joydevpur, Sripur, Madhupur, 
                                Rajendrapur National Park, Chandra and Salna, 
                                all of which have rest-houses that can be used 
                                by tourists on request to the Forest Department.&nbsp;<br>
                                Bangaldesh Parjatan Corporation owns two picnic 
                                spots with Bunglows at Chandra and Salna which 
                                can also be hired by tourists.<br>
                                <br>
                                <font color="#008000">Mosque of Baba Adam :</font> 
                                Of a slightly later date the elegant 6-domed mosque 
                                (43'x36') of Baba Adam in Rampal near Dhaka was 
                                erected by one Malik Kafur during the reign of 
                                the last llyas Shahi Sultan, Jalauddin Fateh Shah 
                                in 1483 A.D. It displays the same characterstic 
                                features of the period such as the faceted octagonal 
                                turrets at 4 corners, the curved cornice, the 
                                facade and 3 mihrabs relieved richly with beautiful 
                                terracotta floral and hanging patterns.<br>
                                <br>
                                <font color="#008000">Star Mosque : </font>A very 
                                beautiful mosque of the city is situated at Mahuttuly 
                                on Abul Khairat Rd; just west of Armanitola Govt. 
                                High School. Architecturally faultless (Mughal 
                                style) is a five-dome mosque with hundreds of 
                                big and small twinkling stars as surface decorations. 
                                The stars have been created by setting pieces 
                                of chinaware on white cement. Seen from the front 
                                and from far it looks as if shining above the 
                                surface of the earth. The inside of it is even 
                                more beautiful that the outside, lovely mosaic 
                                floor and excellent tiles with many floral patterns 
                                set on the walls, are all in complete harmony. 
                                The sitara Masjid was built originally with three 
                                domes in early 18th century by Mirza Ghulam Pir, 
                                a highly respectable Zamindar of Dhaka. Frequently 
                                used in calendars. Entrance: through a lane named 
                                after the mosque.<br>
                                <br>
                                <font color="#008000">Baitul Mukarram Mosque : 
                                </font>Baitul Mukarram Mosque is situated at Purana 
                                Paltan east of Bangladesh Secretariat and north 
                                of Dhaka Stadium. Largest Mosque in the city, 
                                three storied and built after the pattern of the 
                                Kaba Sharif. Very beautiful and costly decorations 
                                in the interior. Long lawn, garden and rows of 
                                fountains to the south and east. The mosque is 
                                on a very high platform. Lovely flight of stairs 
                                lead to it; from the south, east and north. On 
                                the east is a vast varanda which is also used 
                                for prayer and Eid congregation. Below in the 
                                ground floor is a shopping centre.<br>
                                <br>
                                <font color="#008000">Ahsan Manzil Museum : </font>On 
                                the bank of river Buriganga in Dhaka the Pink 
                                majestic Ahsan Manzil has been renovated and turned 
                                into a museum recently. It is an epitome of the 
                                nation's rich cultural heritage. It is the home 
                                of Nawab of Dhaka and a silent spectator to many 
                                events.<br>
                                <br>
                                Today's renovated Ahsan Manzil a monument of immense 
                                historical beauty. It has 31 rooms with a huge 
                                dome atop which can be seen from miles around. 
                                It now has 23 galleries in 31 rooms displaying 
                                of traits, furniture and household articles and 
                                utensils used by the Nawab.</font></font> 
								
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>