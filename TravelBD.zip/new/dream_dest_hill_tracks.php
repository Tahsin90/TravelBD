<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style3.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								
								Decidedly 
                                untypical of Bangladesh in topography and culture, 
                                the Chittagong Hill Tracts have steep jungle hills, 
                                Buddhist tribal peoples and relatively low density 
                                population. The tracts are about 60km (37mi) east 
                                of Chittagong. The region comprises a mass of 
                                hills, ravines and cliffs covered with dense jungle, 
                                bamboo, creepers and shrubs, and has four main 
                                valleys formed by the Karnapuli, Feni, Shangu 
                                and Matamuhur rivers.&nbsp;<br>
                                Rangamati, a lush and verdant rural area belonging 
                                to the Chakma tribe, is open to visitors, as is 
                                Kaptai Lake. The lake, ringed by thick tropical 
                                and semi-evergreen forests, looks like nothing 
                                else in Bangladesh. While the lake itself is beautiful, 
                                the thatched fishing villages located on the lakeshore 
                                are what make a visit really special. Boats that 
                                visit the villages leave from Rangamati. Bring 
                                your swimming gear because you can take a plunge 
                                anywhere.<br>
                                <br>
                                <font color="#008000">The Hills: </font>The Hill 
                                Tract is divided into four valleys surrounded 
                                by the Feni, Karnaphuli, Sangu (Sankhu) and Matamuhuri 
                                rivers and their tributaries. The ranges or hills 
                                of the Hill Tracts rise steeply thus looking far 
                                more impressive than what their height would imply 
                                and extend in long narrow ridges. The highest 
                                peaks on the northern side are Thangnang, Langliang 
                                and Khantiang while those on the southern side 
                                are Ramu, Taung, Keekradang, Tahjindong (4632 
                                ft, highest in Bangladesh), Mowdok Mual, Rang 
                                Tlang and Mowdok Tlang.&nbsp;<br>
                                <br>
                                <font color="#008000">Hill Districts: </font>The 
                                Hill Tracts is divided into three districts, namely 
                                Rangamati, Khagrachari and Bandarban.&nbsp;<br>
                                <br>
                                From Chittagong a 77 km. road amidst green fields 
                                and winding hills will take you to Rangamati, 
                                the headquarters of the Rangamati Hill District 
                                which is a wonderful repository of scenic splendours 
                                with flora and fauna of varied descriptions. It 
                                is also connected by water way from Kaptai.&nbsp;<br>
                                <br>
                                <font color="#008000">Tribal life: </font>The 
                                inhabitants of the Hill Tracts are mostly tribal. 
                                Life of the tribal people is extremely fascinating. 
                                Majority of them are Buddhists and the rest are 
                                Hindus, Christians and Animists. Despite the bondage 
                                of religion, elements of primitiveness is strongly 
                                displayed in their rites, rituals and everyday 
                                life. The tribal families are matriarchal. The 
                                women-folk are more hardworking than the males 
                                and they are the main productive force.&nbsp;<br>
                                <br>
                                The tribal people are extremely self-reliant, 
                                they grow their own food, their girls weave their 
                                own clothes and generally speaking, they live 
                                a simple life. Each tribe has its own dialect, 
                                distinctive dress and rites and rituals. The common 
                                feature is their way of life which still speak 
                                of their main occupation. Some of them take pride 
                                in hunting with bows and arrows. Tribal women 
                                are very skilful in making beautiful handicrafts. 
                                Tribal people are generally peace loving, honest 
                                and hospitable. They usually greet a tourist with 
                                a smile.&nbsp;<br>
                                <br>
                                <font color="#008000">The forests: </font>The 
                                valleys of the Hill Tracts are covered with thick 
                                planted forests. The vegetation in semi-evergreen 
                                to tropical evergreen dominated by tall teak trees. 
                                The natural vegetation can be seen best in the 
                                Rain-khyong valleys of the Bandarban district. 
                                This district provides the country with valuable 
                                wood used for various purposes, besides supplying 
                                wood and bamboo for the Karnaphuli Paper Mills 
                                and the Rayon Mills situated at Chandraghona. 
                                Here a tourist may be lucky to see how huge logs 
                                of wood are being carried to the plain by the 
                                tamed elephants.&nbsp;<br>
                                <br>
                                <font color="#008000">The Lakes: </font>Famous 
                                Kaptai Lake, the largest &quot;man-made&quot; 
                                lake, spreading over 680 sq. km. of crystal-clean 
                                water flanked by hills and evergreen forests lies 
                                in the Rangamati Hill District. The lake was formed 
                                when the Karnaphuli river dam (153 feet high, 
                                1800 feet long crest) was built for the purpose 
                                of hydroelectric power project at Kaptai. The 
                                old Rangamati town was submerged under lake water 
                                and a new town had to be built later. The lake 
                                is full of fish and provides facilities for cruising, 
                                swimming and skiing. There are also facilities 
                                for angling and short trip by Sampan, local name 
                                for country boats.&nbsp;<br>
                                <br>
                                <br>
                                <font color="#008000">Foy's Lake: </font>Set amidst 
                                picturesque surroundings in the railway town-ship 
                                of Pahartali 8 km. from Chittagong, this is an 
                                ideal spot of outing and picnic thronged by thousands 
                                of visitors every week.<br>
                                <br>
                                <font color="#008000">Climate: </font>There are 
                                there main seasons, the dry season (November to 
                                March), which is relatively cool, sunny and dry, 
                                the premonsoon season (April and May), which is 
                                very hot and sunny with occasional shower, and 
                                the rainy season (June to October), which is warm, 
                                cloudy and wet.</font> 
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>