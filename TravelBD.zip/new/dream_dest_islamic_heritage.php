<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style3.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" color="#008000" size="2">
								Star 
                                Mosque:</font><font size="2">&nbsp;<br>
                                A very beautiful mosque of the city is situated 
                                at Mahuttuly on Abul Khairat Rd; just west of 
                                Armanitola Govt. High School. Architecturally 
                                faultless (Mughal style) is a five-dome mosque 
                                with hundreds of big and small twinkling stars 
                                as surface decorations. The stars have been created 
                                by setting pieces of chinaware on white cement. 
                                Seen from the front and from far it looks as if 
                                shining above the surface of the earth.&nbsp;<br>
                                <br>
                                The inside of it is even more beautiful that the 
                                outside, lovely mosaic floor and excellent tiles 
                                with many floral patterns set on the walls, are 
                                all in complete harmony. The sitara Masjid was 
                                built originally with three domes in early 18th 
                                century by Mirza Ghulam Pir, a highly respectable 
                                Zamindar of Dhaka. Frequently used in calendars. 
                                Entrance: through a lane named after the mosque.<br>
                                <br>
                                <font color="#008000"> Baitul Mukarram Mosque:</font>&nbsp;<br>
                                Baitul Mukarram Mosque is situated at Purana Paltan 
                                east of Bangladesh Secretariat and north of Dhaka 
                                Stadium. Largest Mosque in the city, three storied 
                                and built after the pattern of the Kaba Sharif. 
                                Very beautiful and costly decorations in the interior. 
                                Long lawn, garden and rows of fountains to the 
                                south and east.&nbsp;<br>
                                <br>
                                The mosque is on a very high platform. Lovely 
                                flight of stairs lead to it; from the south, east 
                                and north. On the east is a vast varanda which 
                                is also used for prayer and Eid congregation. 
                                Below in the ground floor is a shopping centre.<br>
                                <br>
                                <font color="#008000"> Shait-Gumbad Mosque, Bagerhat:&nbsp;<br>
                                </font> In mid-15th century, a Muslim colony was 
                                founded in the inhospitable mangrove forest of 
                                the Sundarbans near the sea coast in the Bagerhat 
                                district by an obscure saint-General, named Ulugh 
                                Khan Jahan. He was the earliest torch bearer of 
                                islam in the South who laid the nucleus of an 
                                affluent city during the reign of Sultan Nasiruddin 
                                Mahmud Shah (1442-59), then known as 'khalifalabad' 
                                (present Bagerhat).&nbsp;<br>
                                <br>
                                Khan Jahan aborned his city with numerous mosques, 
                                tanks, roads and other public buildings, the spectacular 
                                ruins of which are focused around the most imposing 
                                and largest multidomed mosques in Bangladesh, 
                                known as the Shait-Gumbad Masjid (160'X108'). 
                                The stately fabric of the monument, serene and 
                                imposing, stands on the eastern bank of an unusually 
                                vast sweet-water tank, clustered around by the 
                                heavy foliage of a low-laying countryside, characteristic 
                                of a sea-coast landscape.&nbsp;<br>
                                <br>
                                The mosque roofed over with 77 squat domes, including 
                                7 chauchala or four-sided pitched Bengali domes 
                                in the middle row. The vast prayer hall, although 
                                provided with 11 arched doorways on east and 7 
                                each on north and south for ventilation and light, 
                                presents a dark and sombre appearance inside.<br>
                                <br>
                                It is divided into 7 longitudinal aisles and 11 
                                deep bays by a forest of slender stone columns, 
                                from which springs rows of endless arches, supporting 
                                the domes. Six feet thick, slightly tapering walls 
                                and hollow and round, almost detached corner towers, 
                                resembling the bastions of fortress, each capped 
                                by small rounded cupolas, recall the Tughlaq architecture 
                                of Delhi. The general appearance of this noble 
                                monument with its stark simplicity but massive 
                                character reflects the strength and simplicity 
                                of the builder.<br>
                                <br>
                                <font color="#008000"> Chhota Sona Mosque:&nbsp;<br>
                                </font> One of the most graceful monument of the 
                                Sultanate period is the Chhota Sona Masjid or 
                                Small Golden Mosque at Gaur in Rajshahi Built 
                                by one Wali Muhammad during the reign of Sultan 
                                Alauddin Husain Shah (1493-1519). Originally it 
                                was roofed over with 15 gold-gilded domes including 
                                the 3 Chauchala domes in the middle row, from 
                                which it derives its curious name.<br>
                                <br>
                                <font color="#008000"> Mosque of Baba Adam:</font>&nbsp;<br>
                                Of a slightly later date the elegant 6-domed mosque 
                                (43'x36') of Baba Adam in Rampal near Dhaka was 
                                erected by one Malik Kafur during the reign of 
                                the last llyas Shahi Sultan, Jalauddin Fateh Shah 
                                in 1483 A.D. It displays the same characterstic 
                                features of the period such as the faceted octagonal 
                                turrets at 4 corners, the curved cornice, the 
                                facade and 3 mihrabs relieved richly with beautiful 
                                terracotta floral and hanging patterns.<br>
                                <br>
                                <font color="#008000"> The Shrine of Hazrat Shah 
                                Jalal:&nbsp;<br>
                                </font> Among the several places of historical 
                                interest in Sylhet town is the shrine of Saint 
                                Hazrat Shah Jalal. Even today, more than six hundred 
                                years after his death, the shrine is visited by 
                                innumerable devotees of every caste and creed, 
                                who make the journey from far away places. Hazrat 
                                Shah Jalal is credited with the help extended 
                                to the Muslim army which conquered Sylhet in 1303 
                                A.D.<br>
                                <br>
                                <font color="#008000"> Shrine of Sultan Bayazid 
                                Bostami:</font>&nbsp;<br>
                                Situated on a hillock in Nasirabad, about 6 km. 
                                to the north-west of Chittagong town, this shrine 
                                attracts a large number of visitors and pilgrims. 
                                At its base is a large tank with several hundred 
                                tortoises. Tradition has it that these animals 
                                are the descendants of the evil spirits (genii) 
                                who were cast into this shape because they incurred 
                                the wrath of the great saint who visited the place 
                                about 1,100 years ago.<br>
                                <font color="#008000"><br>
                                Shrine of Shah Amanat:&nbsp;<br>
                                </font> The shrine of Shah Amanat is another place 
                                of religious attraction. Located in the heart 
                                of the town, the shrine is visited by hundreds 
                                of people everyday who pay homage to the memory 
                                of the saint who lived in the 19th century.</font></font> 
								
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>