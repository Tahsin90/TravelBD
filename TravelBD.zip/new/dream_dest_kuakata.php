<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								Kuakata, 
                                locally known as Sagar Kannya (Daughter of the 
                                Sea) is a rare scenic beauty spot on the southernmost 
                                tip of Bangladesh. Kuakata in Latachapli union 
                                under Kalapara Police Station of Patuakhali district 
                                is about 30 km in length and 6 km in breadth. 
                                It is 70 km from Patuakhali district headquarters 
                                and 320 km from Dhaka. At Kuakata excellent combination 
                                of the picturesque natural beauty, sandy beach, 
                                blue sky, huge expanse of water of the Bay and 
                                evergreen forest in really eye-catching.&nbsp;<br>
                                <br>
                                The name Kuakata have originated from Kua-Well 
                                dug on the sea shore by the early Rakhine settlers 
                                in quest of collecting drinking water, who landed 
                                on Kuakata coast after explled from Arakan by 
                                Moughals. Afterwards, it has become a tradition 
                                of digging Kua-Well in the neighbourhood of Rakhaine 
                                homestead for collection water for drinking purpose 
                                and general use.<br>
                                <br>
                                </font><font color="#008000">Tourist Attractions 
                                : </font><font color="#000000">Kuakata is one 
                                of the rarest places which has the unique beauty 
                                of offering the full view of the rising and setting 
                                of crimson sun in the water of the Bay of Bengal 
                                in a calm environment. That perhaps makes Kuakata 
                                one of the world's unique beaches. The long and 
                                wide beach at Kuakata has a typical natural setting. 
                                This sandy beach has gentle slopes into the Bay 
                                of Bengal and bathing there is as pleasant as 
                                is walking or diving.&nbsp;<br>
                                <br>
                                Kuakata is truly a virgin beach-a sanctuary for 
                                migratory winter birds, a series of coconut trees, 
                                sandy beach of blue Bay, a feast for the eye. 
                                Forest, boats plying in the Bay of Bengal with 
                                colourful sails, fishing, towering cliffs, surfing 
                                waves everything here touches every visitor's 
                                heart. The unique customs and costumes of the 
                                'Rakhyne' tribal families and Buddhist Temple 
                                of about hundred years old indicate the ancient 
                                tradition and cultural heritage, which are objects 
                                of great pleasure Kuakata is the place of pilgrimage 
                                of the Hindus and Buddhist communities.<br>
                                <br>
                                Innumerable devotees arrive here at the festival 
                                of 'Rush Purnima' and 'Maghi Purnima'. On these 
                                two days they take holy bath and traditional fairs 
                                are held here. All these additional offers to 
                                panoramic beauty make the beach more attractive 
                                to the visitors. One should visit Kuakata and 
                                discover the lovely grace of Bangladesh.<br>
                                <br>
                                </font><font color="#3C911B">Means of Communication 
                                : </font><font color="#000000">There exists road 
                                commiunication between Dhaka and Patuakhali district 
                                headquaters. Accessible by road, water or air 
                                transport up to Barisal. Then one may travel by 
                                road or water to Kuakata or Patuakhali.&nbsp;<br>
                                <br>
                                BRTC has introduced direct bus service from Dhaka 
                                to Kuakata via Barisal. Besides that, Bangladesh 
                                Parjatan Corporation, National Tourism Organization 
                                may organize guided package tours from Dhaka to 
                                Kuakata on demand.&nbsp;<br>
                                <br>
                                </font><font color="#3C911B">Parjatan Facilities 
                                : </font><font color="#000000">Parjatan Holiday 
                                Homes at Kuakata is an ideal tourist resort having 
                                a number of facilities for the tourists.</font></font> 
                              <br><br>
							  <font color="#3C911B">Other 
                                facilities : </font><font color="#000000">A pond 
                                of crystal clean sweet water beside the motel 
                                attract the tourists.&nbsp;<br>
                                For advance reservation and further details one 
                                may contact :&nbsp;<br>
                                Central Reservation, Bangladesh Parjatan Corporation.<br>
                                Head Office, 233, Airport Road, Tejgaon, Dhaka.</font></font> 
								
								
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>