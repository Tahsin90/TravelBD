<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style3.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								Paharpur 
                                is a small village 5 km. west of Jamalganj in 
                                the greater Rajshahi district where the remains 
                                of the most important and the largest known monastery 
                                south of the Himalayas has been excavated. This 
                                7th century archaeological find covers approximately 
                                an area of 27acres of land. The entire establishment, 
                                occupying a quadrangular court, measuring more 
                                than 900 ft. externally on each side, has high 
                                enclosure- walls about 16 ft. in thickness and 
                                from 12 ft. to 15 ft. height. With elaborate gateway 
                                complex on the north, there are 45 cells on the 
                                north and 44 in each of the other three sides 
                                with a total number of 177 rooms. The architecture 
                                of the pyramidal cruciform temple is profoundly 
                                influenced by those of South-East Asia, especially 
                                Myanmar and Java.<br>
                                <br>
                                A small site-Museum built in 1956-57 houses the 
                                representative collection of objects recovered 
                                from the area.The excavated findings have also 
                                been preserved at the Varendra Research Museum 
                                at Rajshahi. The antiquities of the museum include 
                                terracotta plaques, images of different gods and 
                                goddesses, potteries, coins, inscriptions, ornamental 
                                bricks and other minor clay objects.<br>
                                <br>
                                <br>
                                <font color="#008000">Chhota Sona Mosque : </font>One 
                                of the most graceful monument of the Sultanate 
                                period is the Chhota Sona Masjid or Small Golden 
                                Mosque at Gaur in Rajshahi Built by one Wali Muhammad 
                                during the reign of Sultan Alauddin Husain Shah 
                                (1493-1519). Originally it was roofed over with 
                                15 gold-gilded domes including the 3 Chauchala 
                                domes in the middle row, from which it derives 
                                its curious name.<br>
                                <br>
                                <br>
                                <font color="#008000">Varendra Research Museum 
                                : </font>Situated at Rajshahi, this museum has 
                                a rich collection of objects of Mohenjodaro and 
                                also of 16th to 19th century A.D. This is devoted 
                                to the study of ancient history and culture. Its 
                                rich collections contain interesting objects of 
                                past Hindu, Buddhist and Muslim heritage. It is 
                                located at the heart of Rajshahi town and maintarned 
                                by Rajshahi University authority. The year of 
                                its formal establishment is 1910 A.D. Admission 
                                is free.<br>
                                <br>
                                <font color="#008000">Puthia :</font></font><font color="#3C911B" face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                                </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Puthia 
                                has the largest number of historically important 
                                Hindu structures in Bangladesh. The most amazing 
                                of the village''s monuments is the Govinda Temple, 
                                which was erected between 1823 and 1895 by one 
                                of the maharanis of the Puthia estate. It''s a 
                                large square structure crowned by a set of miniature 
                                ornamental towers. It''s covered by incredibly 
                                intricate designs in terracotta depicting scenes 
                                from Hindu epics, which give it the appearance 
                                of having been draped by a huge red oriental carpet.<br>
                                <br>
                                The ornate Siva Temple is an imposing and excellent 
                                example of the five-spire Hindu style of temple 
                                architecture common in northern India. The ornate 
                                temple has three tapering tiers topped by four 
                                spires. It''s decorated with stone carvings and 
                                sculptural works which unfortunately were disfigured 
                                during the War of Liberation. The village''s 16-century 
                                Jagannath Temple is one of the finest examples 
                                of a hut-shaped temple: measuring only 5m (16ft) 
                                on each side, it features a single tapering tower 
                                which rises to a height of 10m (33ft). Its western 
                                facade is adorned with terracotta panels of geometric 
                                design.<br>
                                <br>
                                Puthia is 23km (14mi) east of Rajshahi and 16km 
                                (10mi) west of Natore. Catch a bus from either 
                                town. Puthia is 1km (6mi) south of the highway.</font></font> 
								
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>