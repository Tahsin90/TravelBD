<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style2.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								The 
                                Sundarbans are the largest littoral mangrove belt 
                                in the world, stretching 80km (50mi) into the 
                                Bangladeshi hinterland from the coast. The forests 
                                aren't just mangrove swamps though, they include 
                                some of the last remaining stands of the mighty 
                                jungles which once covered the Gangetic plain. 
                                The Sundarbans cover an area of 38,500 sq km, 
                                of which about one-third is covered in water. 
                                Since 1966 the Sundarbans have been a wildlife 
                                sanctuary, and it is estimated that there are 
                                now 400 Royal Bengal tigers and about 30,000 spotted 
                                deer in the area.&nbsp;<br>
                                <br>
                                The park is also home to sea gypsy fishing families 
                                who catch fish using trained otters. To see this 
                                pristine environment, you need to get a permit 
                                from the Divisional Forest Office in Khulna. With 
                                permit in hand, it's possible to hire a boat from 
                                Mongla or Dhangmari to get you to Hiron Point. 
                                From Hiron Point you will have to hire a guide 
                                to take you into the park.<br>
                                <br>
                                Sundarbans is home to many different species of 
                                birds, mammals, insects, reptiles and fishes. 
                                Over 120 species of fish and over 260 species 
                                of birds have been recorded in the Sundarbans. 
                                The Gangetic River Dolphin (Platanista gangeticus) 
                                is common in the rivers. No less than 50 species 
                                of reptiles and eight species of amphibians are 
                                known to occur. The Sundarbans now support the 
                                only population of the Estuarine, or Salt-Water 
                                Crocodile (Crocodylus parasus) in Bangladesh, 
                                and that population is estimated at less than 
                                two hundred individuals.<br>
                                <br>
                                Here land and water meet in many novel fashions, 
                                Wildlife presents many a spectacle. No wonder, 
                                you may come across a Royal Bengal Tiger swimming 
                                across the streams or the crocodiles basking on 
                                the river banks. With the approach of the evening 
                                herds of deer make for the darking glades where 
                                boisterous monkeys shower Keora leaves from above 
                                for sumptuous meal for the former. For the botanist, 
                                the lover of nature, the poet and the painter 
                                this land provides a variety of wonder for which 
                                they all crave.&nbsp;<br>
                                <br>
                                It's beauty lies in its unique natural surrounding. 
                                Thousands of meandering streams, creeks, rivers 
                                and estuaries have enhanced its charm. Sundarbans 
                                meaning beautiful forest is the natural habitat 
                                of the world famous Royal Bengal Tiger, spotted 
                                deer, crocodiles, jungle fowl, wild boar, lizards, 
                                theses monkey and an innumerable variety of beautiful 
                                birds. Migratory flock of Siberian ducks flying 
                                over thousands of sail boats loaded with timber, 
                                golpatta (round-leaf), fuel wood, honey, shell 
                                and fish further add to the serene natural beauty 
                                of the Sundarbans.&nbsp;<br>
                                
                                <br>
                                <font color="#008000">General Information</font><br>
                                <br>
                                <font color="#008000">AREA</font>: Nearly 2400 
                                sq. miles or 6000 sq. km.&nbsp;<br>
                                <br>
                                <font color="#008000">FOREST LIMITS: </font>North-Bagerhat, 
                                Khulna and Sathkira districts : South-Bay of Bengal; 
                                East-Baleswar (or Haringhata) river, Perojpur, 
                                Barisal district, and West-Raimangal and Hariabhanga 
                                rivers which partially form Bangladesh boundary 
                                with West Bengal in India.<br>
                                <br>
                                <font color="#008000">MAIN ATTRACTIONS: </font>Wildlife 
                                photography including photography of the famous 
                                Royal Bengal Tiger, wildlife viewing, boating 
                                inside the forest will call recordings, nature 
                                study, meeting fishermen, wood-cutters and honey-collectors, 
                                peace and tranquility in the wilderness, seeing 
                                the world's largest mangrove forest and the riverine 
                                beauty.<br>
                                <br>
                                <font color="#008000">FAMOUS SPOTS: </font>Hiron 
                                Point (Nilkamal) for tiger, deer, monkey, crocodiles, 
                                birds and natural beauty. Katka for deer, tiger, 
                                crocodiles, varieties of birds and monkey, morning 
                                and evening symphony of wild fowls. Vast expanse 
                                of grassy meadows running from Katka to Kachikhali 
                                (Tiger Point) provide opportunities for wild tracking.&nbsp;<br>
                                Tin Kona Island for tiger and deer.<br>
                                <br>
                                Dublar Char (Island) for fishermen. It is a beautiful 
                                island where herds of spotted deer are often seen 
                                to graze.<br>
                                <br>
                                <font color="#008000">Means of Communication: 
                                </font>Water transport is the only means of communication 
                                for visiting the Sundarbans from Khulna or Mongla 
                                Port. Private motor launch, speed boats, country 
                                boats as well as mechanised vessel of Mongla Port 
                                Authority might be hired for the purpose. From 
                                Dhaka visitors may travel by air, road or rocket 
                                steamer to Khulna - the gateway to the Sundarbans. 
                                Most pleasant journey from Dhaka to Khulna is 
                                by Paddle Steamer, Rocket presenting a picturesque 
                                panorama of rural Bangladesh. Day and night-long 
                                coach services by road are also available. The 
                                quickest mode is by air from Dhaka to Jessore 
                                and then to Khulna by road.<br>
                                <br>
                                <font color="#008000">Journey time: </font>It 
                                varies depending on tides against or in favour 
                                in the river. Usually it takes 6 to 10 hours journey 
                                by motor vessel from Mongla to Hiron Point or 
                                Katka.<br>
                                Accommodation Inside the forest<br>
                                <br>
                                <font color="#008000">Hiron Point : </font>Comfortable 
                                three-storied Rest-House of the Mongla Port Authority. 
                                Prior booking is to be made.<br>
                                <br>
                                <font color="#008000">Katka : </font>Forest Department 
                                Rest-House located here. Prior booking essential.&nbsp;<br>
                                Journey by Rocket Steamer to Mongla and Khulna<br>
                                <br>
                                Minimum Journey time is 22 Hours for Mongla and 
                                24 Hours for Khulna from Dhaka.<br>
                                <br>
                                <font color="#008000">Entry Permission: </font>Prior 
                                permission must be obtained through written application 
                                from the Divisional Forest Office, Circuit House 
                                Road, Khulna (Phone 20665, 211731) to visit the 
                                Sundarbans. Required entrance fees for visitors, 
                                vessel or boat payable at the relevant forest 
                                station/range office.<br>
                                <br>
                                Fee for Commercial Photography<br>
                                Movie Tk. 5,000.00 per role exposed<br>
                                Video Tk. 4,000.00 per Cassette<br>
                                Still Tk. 1,000.00 per role exposed<br>
                                <br>
                                <font color="#008000">Guided Tours: </font>Bangladesh 
                                Parjatan Corporation &amp; other tour operators 
                                offers all-inclusive guided package fours from 
                                Dhaka to Sundarbans and return during the tourist 
                                season (October to March).&nbsp;<br>
                                <br>
                                <font color="#008000">Climate: </font>Climate 
                                in the Sundarbans is moderate. Air is humid. Full 
                                monsoon is from June to September. The annual 
                                rainfall average between 65&quot; and 70&quot;. 
                                During ebb-tide the forest becomes bare by 6-7 
                                feet and at high tide (30 miles and hour) the 
                                entire territory of the forest floats on water.<br>
                                <br>
                                <font color="#008000">Life in Forest: </font>Only 
                                means of transportation inside the forest is boat. 
                                There is no road, no trail of a path anywhere. 
                                The wood-cutters make temporary dwellings at the 
                                edge of the forest at a height of 8-10 feet for 
                                fear of wild animals others live on boats. In 
                                the chandpai region it is fascinating to see the 
                                nomadic fishermen (living with families on boats) 
                                catching fish with the help of trained offers. 
                                Exciting activities take place in Dublar Char 
                                in the forest where fishermen from Chittagong 
                                gather for four months (mid Oct. to mid Feb.) 
                                to catch and dry fish. But the most daring and 
                                exciting of all activities is presented by the 
                                honey-collectors who work in groups for just two 
                                months (April-May) and it is interesting to see 
                                how they locate a hive and then collect honey.<br>
                                
                                
                               
                                <br>
                                <font color="#008000">Tourist season &amp; Shooting: 
                                </font>Best time to visit the Sundarbans is from 
                                November to March. Exciting honey collection season 
                                is during April-May. Hunting is prohibited by 
                                law in the country for the preservation of wildlife. 
                                Certain species of birds, however, can be shot 
                                with prior permission of the Divisional Forest 
                                Officer, Khulna, (Phone : 20665 &amp; 21173).<br>
                                <br>
                                <font color="#008000">Visit to the Forest: </font>Permission 
                                from the Division Forest Officer, Khulna is required 
                                to visit to the forest. Cholera vaccine is to 
                                be taken well in advance. Anti-malarial, anti-diarrhoeal, 
                                insectrepellent cream, drinking water, green coconuts, 
                                medical kit, light tropical dress, thick rubber 
                                soled boots etc. are to be carried with the tourist. 
                                It will be wise to take the help of an experienced 
                                guide to make the journey fruitful.</font></font> 
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
