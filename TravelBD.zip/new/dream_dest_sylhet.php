<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="dream_style2.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image10.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

								<tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								Nestled 
                                in the picturesque Surma Valley amidst scenic 
                                tea plantations and lush green tropical forests, 
                                greater Sylhet is a prime attraction for all tourists 
                                visiting Bangladesh. Laying between the Khasia 
                                and the Jaintia hills on the north, and the Tripura 
                                hills on the south, Sylhet breaks the monotony 
                                of the flatness of this land by a multitude of 
                                terraced tea gardens, rolling countryside and 
                                the exotic flora and fauna. Here the thick tropical 
                                forests abound with many species of wildlife, 
                                spread their aroma around the typical hearth and 
                                homes of the Mainpuri Tribal maidens famous for 
                                their dance.&nbsp;<br>
                                <br>
                                The Sylhet valley is formed by a beautiful, winding 
                                pair of rivers named the Surma and the Kushiara 
                                both of which are fed by innumerable hill streams 
                                from the north and the south. The valley has good 
                                number of haors which are big natural depressions. 
                                During winter these haors are vast stretches of 
                                green land, but in the rainy season they turn 
                                into turbulent seas.&nbsp;<br>
                                <br>
                                These haors provide a sanctuary to the millions 
                                of migratory birds who fly from Siberia across 
                                the Himalayas to avoid the severe cold there. 
                                Sylhet has also a very interesting and rich hilstory, 
                                Before the conquest by the Muslims, it was ruled 
                                by local chieftains. In 1303, the great Saint 
                                Hazrat Shah Jalal came to Sylhet from Delhi with 
                                a band of 360 disciples to preach islam and defeated 
                                the then Raja Gour Gobinda.&nbsp;<br>
                                <br>
                                Sylhet thus became a district of saints, shrines 
                                and daring but virile people. Its rich potentialities 
                                became easily attractive and the 18th century 
                                Englishmen made their fortune in tea plantation. 
                                About 80 km. from Sylhet town connected by road 
                                and rail, Srimangal, which is known as the tea 
                                capital of Bangladesh, is the actual tea centre 
                                of the area. For miles and miles around, the visitor 
                                can see the tea gardens spread like a green carpet 
                                over the plain land or on the sloping hills. A 
                                visit to the tea plantation in Sylhet is a memorable 
                                experience. Sylhet, the tea granary of Bangladesh, 
                                not only has over 150 tea gardens but also proudly 
                                possesses three largest tea gardens in the world 
                                both in area and production.<br>
                                <br>
                                <font color="#008000"> The Shrine of Hazrat Shah 
                                Jalal: </font> Among the several places of historical 
                                interest in Sylhet town is the shrine of Saint 
                                Hazrat Shah Jalal. Even today, more than six hundred 
                                years after his death, the shrine is visited by 
                                innumerable devotees of every caste and creed, 
                                who make the journey from far away places. Legend 
                                says, the great saint who came from Delhi to preach 
                                Islam and defeated the then Hindu Raja (king) 
                                Gour Gobinda, transformed the witchcraft followers 
                                of the Raja into catfishes which are still alive 
                                in the tank adjacent to the shrine Swords, the 
                                holy Quran and the robes of the holy saint are 
                                still preserved in the shrine.&nbsp;<br>
                                <br>
                                <font color="#008000"> Hairpur Gas Field and other 
                                spots: </font> Twentytwo kilometers from Sylhet 
                                town is the Haripur Gas Field and at 35 km. point 
                                is the Jaintiapur's Rajbari.<br>
                                <br>
                                Only 5 km. from Jaintiapur is Jaflong, a scenic 
                                spot amidst tea gardens. At about 35 km. north-west 
                                of Sylhet town, linked by rail, road and river 
                                is Chhatak, the seat of Assam Bengal Cement Factory, 
                                Chhatak is famous for orange garden.<br>
                                <br>
                                <font color="#008000"> Tamabil-Jaflong: </font> 
                                Situated amidst splendid panorama, Tamabil is 
                                a border outpost on Sylhet-Shilong Road about 
                                55 km. away from Sylhet town. Besides enchanting 
                                views of the area one can also have a glimpse 
                                of the waterfalls across the border from Tamabil. 
                                Jaflong is also a scenic spot nearby amidst tea 
                                gardens and rate beauty of rolling stones from 
                                hills.<br>
                                <br>
                                <font color="#008000"> Manipuri Dance: </font> 
                                An interesting feature of Sylhet region is the 
                                aboriginal tribes such as the Tipperas, the Monipuris, 
                                Khasis and Garos who still live in their primitive 
                                ways in the hills, practising their age-old rites, 
                                rituals, customs and traditions. During festivals 
                                such as, Rash Leela (Full-moon night in February) 
                                and Doljatra, the attractive young girls dressed 
                                in colorful robes, dance with the male members 
                                of their choice &amp; love. The Monipuris perform 
                                their famous dance, based on allegorical love 
                                themes of the ancient mythology.<br>
                                <br>
                                <font color="#008000"> Handicrafts: </font> Sylhet 
                                is well-known for its wide variety of exquiste 
                                handicrafts. Well-known Sylhet cane products such 
                                as chair, table, tea trays, flower vases, bags 
                                and the exquisitely designed fine Sital Pati (a 
                                kind of mattress having natural cooling effect) 
                                are colorful souvenirs.<br>
                                For accommodation at Sylhet town, some reasonably 
                                good hotels are available. Rest-house accommodation 
                                at Srimangal and other places are also available 
                                for tourists.&nbsp;<br>
                                <br>
                                <br>
                                <font color="#008000"> Temple of Sri Chaitannya 
                                Dev: </font> About 500 years old famous temple 
                                of Sri Chaitanya Dev is located at Dhaka Dakhin 
                                about 45 km south-east from Sylhet town. The place 
                                is revered from being the ancestral home of the 
                                famous Vaishnava saint. Yearly fair is organised 
                                on the fullmoon day of the Bangla month Falgun. 
                                Hundreds and thousands of devotees from home and 
                                abroad attend this colorful fair.<br>
                                <br>
                                <font color="#008000"> Shahi Edgah: </font> Three 
                                kilometers to the north-east of the circuit house, 
                                the Shahi Eidgah was built on a hill by the Mughal 
                                Emperor Aurangazeb in the 17th century. It looks 
                                like a grade fort but is actually meant for Eid 
                                congreation-the two biggest Muslim festivals<br>
                                <br>
                                <font color="#008000"> Gour Gobinda Fort: </font> 
                                The Murarichand Government College is situated 
                                in a beautiful surrounding on a hillttop. To the 
                                north-west of the college lie the remains of King 
                                Gour Govinda's Fort.<br>
                                <br>
                                <font color="#008000"> Jaintiapur: </font> Situated 
                                43 km. to the north of Sylhet town, on the Sylhet- 
                                Shillong road, Jaintiapur was the capital of an 
                                ancient kingdom which included the khasi and Jaintia 
                                Hills and plains of Jainta. Interesting ruins 
                                of this forgotten period lie scattered throughout 
                                Jaintiapur. A drive to Jaintiapur is an interesting 
                                and worthwhile experience<br>
                                <br>
                                <font color="#008000">Srimongol: </font> Srimongal 
                                is famous for the largest tea gardens of world 
                                covered by lush green carpet. One can have a look 
                                into the spectacular tea processing at Tea Research 
                                Institute. Bangladesh produces and exports a large 
                                quantity of high quality tea every year. Most 
                                of the tea estates are in Sremongol. It is called 
                                "The land of two leaves and a bud". It is also 
                                called camellia, green carpet or Tea Mountain. 
                                There are a lot of tea estates including the largest 
                                one in the world. The terraced tea garden, pineapple, 
                                rubber and lemon plantations from a beautiful 
                                landscape. It is known as the tea capital in Bangladesh. 
                                Just offer entering into the tea estates the nice 
                                smells and green beauty will lead you many kilometers 
                                away.&nbsp;<br>
                                <br>
                                <font color="#008000"> Lawacherra Rain Forest: 
                                </font> Lawacherra Rain Forest is one of the important 
                                &amp; well-reserved forests in Bangladesh. Here 
                                visitor may see gibbons swimming through the trees 
                                and birds like bee-eater owls parrot. It is a 
                                good habitant of Deer, leopard, wild chicken, 
                                squirrel, and python. Don't miss it especially 
                                if you are bird watcher. The terrain is hilly 
                                and vegetation is fairly thick. Only one rare 
                                Chloroform tree of Asia is here and a prime attraction 
                                of travel<br>
                                <br>
                                Kasia &amp; Manipuri is two important ethnic-tribe 
                                live here. Manipuri is famous for its rich culture 
                                especially for dancing, singing. They are also 
                                famous for their traditional weaving. You can 
                                buy their handicrafts exquisitely woven woolen. 
                                Shawls, Sharee, Napkin, bed-cover and some should 
                                a bags. It is known as colorful community. Kasia 
                                tribe is famous for their betel leaf cultivation. 
                                They make their villages high on hilltop in deep 
                                forest and so far from town. It is like " a Piece 
                                of paradise". Certainly it will please you.<br>
                                <br>
                                Pineapple cultivation in numerable rows of Pineapple 
                                cultivation covering largest area is very amazing 
                                and fascinating. Largest quantity of pineapple 
                                grown here of Bangladesh. It is also sweetest 
                                and best quality. Pineapple is really a greatest 
                                offer of summer but now it is cultivated all the 
                                year round. So, you can enjoy the juicy summer 
                                fruit in any time coming to its real field. Just 
                                after entering into pineapple plantation. It can 
                                be highlight for you in Sremongol.<br>
                                <br>
                                <font color="#008000"> Madhabkunda: </font> Madhabkunda 
                                surrounded by lush tea estates and full of waters 
                                lilies is a unique one. Magurchara ruined gas 
                                &amp; Oil reserved field, which was blasted while 
                                digging 3 years ago and was burning an 500-feet 
                                height for more than 3 months. A lot of burnt 
                                trees now carrying the symbols of digester. Ever 
                                where a lot of rubber &amp; lemon plantation form 
                                a beautiful landscape. And you can have a visit 
                                to Madhobkundo water fall .&nbsp; </font></font> 

                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							

                      

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>