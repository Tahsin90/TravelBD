<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="festival_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image12.jpg" height="160" width="666" />
<div id="header2" class="grid_12">
<img src="image14.jpg" height="160" width="666" />
</div>

<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                             <h1>FAIR AND FESTIVALS</h1>
							 <br>
							 <p>
							 	
Fairs and festivals have always played a significant
 role in the life of the citizens of this country. 
 They derive from them a great amount of joy, entertainment
 and color for life. While most of the festivals have sprung
 from religious rituals, the fairs have their roots in the
 very heart of the people, irrespective of religion, caste or creed. <br>
 <br>
 
		<h2>Pahela Baishakh	</h2>
		The advent of Bengali New Year is gaily observed 
		throughout the country. The Day (mid-April) is a 
		public holiday. Most colorful daylong gatherings 
		along with arrangement of cultural program and 
		traditional Panta at Ramna Park, is a special 
		feature of Pahela Baishakh. Tournaments, boat 
		races etc. are held in cities and villages amidst 
		great jubilation. Many fairs are held in Dhaka and
		other towns and villages. <br><br>
		
		<h2>Independence Day</h2>
		March 26 is the day of Independence of Bangladesh.
		It is the biggest state festival. This day is most
		befittingly observed and the capital wears a festive 
		look. It is a public holiday. The citizens of Dhaka 
		wake up early in the morning with the booming of guns 
		heralding the day. Citizens including government leaders 
		and sociopolitical organizations and freedom fighters place
		floral wreaths at the National Martyrs Monument at Savar.
		Bangla Academy, Bangladesh Shilpakala Academy and other
		socio-cultural organizations hold cultural functions. At
		night the main public buildings are tastefully illuminated
		to give the capital city a dazzling look. Similar functions
		are arranged in other parts of the country.<br><br>
		
		<h2>21st Feb, the National Mourning Day and World Mother Language Day</h2>
		21 February is observed throughout the country to pay respect and homage to 
		the sacred souls of the martyrs' of Language Movement of 1952. Blood was shed
		on this day at the Central Shahid Minar (near Dhaka Medical College Hospital) 
		area to establish Bangla as a state language of the then Pakistan. All
		subsequent movements including struggle for independence owe their 
		origin to the historic language movement. The Shahid Minar (martyrs monument)
		is the symbol of sacrifice for Bangla, the mother tongue. The day is 
		closed holiday. Mourning procedure begin in Dhaka at midnight with the 
		song Amar vaier raktay rangano ekushay February (21st February, the day
		stained with my brothers' blood). Nationals pay homage to the martyrs by
		placing flora wreaths at the Shahid Minar. Very recently the day has been
		declared World Mother Language Day by UNESCO.<br><br>
		
		<h2>Eid-e-Miladunnabi</h2>
		Eid-e-Miladunnabi is the birth and death
		day of Prophet Muhammad (s). He was born
		and died the same day on 12th Rabiul Awal
		(Lunar Month). The day is national holiday,
		national flag is flown atop public and private 
		houses and special food is served in orphanages,
		hospitals and jails. At night important public
		buildings are illuminated and milad mahfils are held.<br><br>
		
		<h2>Eid-ul-Fitr</h2>
		The biggest Muslim festival observed throughout
		the world. This is held on the day following 
		the Ramadan or the month of fasting. In Dhaka
		big congregations are held at the National
		Eidgah and many mosques.<br><br>

		<h2>Eid-ul-Azha</h2>
		Second biggest festival of the Muslims. 
		It is held marking the Hajj in Mecca on 
		the 10th Zilhaj, the lunar month. Eid 
		congregations are held throughout the
		country. Animals are sacrificed in reminiscence
		of Hazrat Ibrahim's (AM) preparedness for the 
		supreme sacrifice of his beloved son to Allah. It is a public holiday.<br><br>

		<h2>Durga Puja</h2>
		Durga Puja, the biggest festival of the Hindu community
		continues for ten days, the last three days being culmination
		with the idol immersed in rivers. In Dhaka the big celebrations 
		are held at Dhakeswari Temple, where a fair is also held and at
		the Ram Krishna Mission. <br><br>
		
	    <h2>Christmas</h2>
		Christmas, popularly called "Bara Din (Big Day)", 
		is celebrated with pomp in Dhaka and elsewhere in 
		the country. Several day-long large gatherings are
		held at St. Mary's Cathedral at Ramna, Portuguese 
		Church at Tejgaon, Church of Bangladesh (Protestant)
		on Johnson Road and Bangladesh Baptist Sangha at 
		Sadarghat Dhaka. Functions include illumination of 
		churches, decorating Christmas tree and other Christian festivities.<br><br>

		<h2>Rabindra & Nazrul Jayanti</h2>
		Birth anniversary of the noble laureate Rabindranath 
		Tagore on 25th Baishakh (May) and that of the National 
		Poet Kazi Nazrul Islam on 11th Jaystha (May) are observed
		throughout the country. Their death anniversaries are also
		marked in the same way. Big gatherings and song sessions
		organized by socio-cultural organizations are salient 
		features of the observance of the days.<br><br>
		
		Tagore is the writer of our national anthem while National Poet Kazi Nazrul Islam is famous as Rebel Poet.<br>



				 
				 
                                 	


 
 
                             </p>

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
