<?php
	include 'config.php';
	
?>



<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="flora_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image12.jpg" height="160" width="666" />
<div id="header2" class="grid_12">
<img src="image15.jpg" height="160" width="666" />
</div>

<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                             <h1>FLORA & FAUNA</h1>
							 <br>
							 <p>
                                 	
Abundance of Bangladesh's bird life makes it an 
ornithologist's paradise. Of the 525 recorded species, 
350 are resident. Among them are bulbul, magpie, robin
, common game birds, cuckoos, hawks, owls, crows, 
kingfishers, woodpeckers, parrots and myna. A wide 
variety of warblers are also found. Some of them are
migrants and appear only in winter. The migratory
and seasonal birds are pre-dominantly ducks.<br>
<br>
Of the 200 species of mammals, the pride of place 
goes to the Royal Bengal Tiger of the Sunderbans, 
the largest block of littoral forests spreading 
over an area of 6,000 sq. km. Next comes the elephants
 found mainly in the forests of the Chittagong Hill 
 Tracts districts. South Himalayan black bear and 
 the Malayan bear are also seen here. Six types of 
 deer are found in the hill tracts and the Sunderbans.
 Of them the spotted deer, barking deer and sambar
 are the most familiar. Clouded leopard, leopard 
 cat, mongoose, jackal and rhesus monkey are also found.<br>
 <br>
 Among the bovine animals, three species- buffalo, 
 ox and gayal- are found. There are about 150 species
 of reptiles of which the sea turtle, river tortoise,
 mud turtle, crocodiles, gavial, python, krait and 
 cobra and common. About 200 species of marine and
 freshwater fish are also found. Prawns and lobsters 
 are available in plenty for local consumption and export.<br>
 <br>
 In the shallow water of the floodplains, ponds and swamps 
 of the country various hydrophytes and floating ferns grow 
 in abundance. Tall grasses present a picturesque site near 
 the banks of the rivers and the marshes. Around 60% of the
 Gangetic plain is under rice paddy and jute cultivation. 
 The village homes are usually concealed by the lush green 
 foliage of a wide variety of trees, thickets of bamboo 
 and banana plants. A characteristic feature of the landscape
 is the presence of a variety of palm and fruit trees.<br>
 <br>
 Each season produces its special variety of flowers 
 in Bangladesh; among them, the prolific Water Hyacinth
 flourishes. Its carpet of thick green leaves and blue 
 flowers gives the impression that solid ground lies 
 underneath. Other decorative plants, which are widely
 spread are Jasmine, Water Lily, Rose, Hibiscus,
 Bougainvillea, Magnolia, and an incredible diversity 
 of wild orchids in the forested areas.<br>
 <br>
 Lying close to the Himalayas, the Sylhet area 
 has extensive natural depressed lands locally 
 called 'haors' (pronounced 'howers', wetlands)
 . During the winter season they are home to huge 
 flocks of wild fowl. Outstanding species include 
 the rare Baer's pochard and Pallas' Fish Eagle, 
 along with a great number of ducks . Other important
 habitats are the remaining fragments of evergreen
 and teak forests, especially along the Indian 
 border near the Srimongal area. <br>
 <br>
 
The Blue-bearded Bee-eater, Redheaded
 Trogon and a wide variety of forest 
 birds, including rare visitors are 
 seen in these forests. One of two
 important coastal zones is the Noakhali 
 region, with emphasis on the islands near
 Hatiya, where migratory species and a
 variety of wintering waders find suitable
 refuge. These include rare viitors like
 Spoonbilled Sandpiper, Nordman's 
 Greenshank and flocks of Indian Skimmers.<br>
 <br>
 The forest cover of Bangladesh is only about 9 percent.
 The thickest forests are in the coastal Sunderbans 
 and the hill tracts in the northeast. Extensive areas
 of Rajshahi, Dinajpur and Kushtia are under mango, 
 litchi, sugarcane and tobacco cultivation.<br>
 <br>

 
 
                             </p>

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>