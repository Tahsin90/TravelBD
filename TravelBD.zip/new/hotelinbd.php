<?php
	include 'config.php';
	
?>



<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="hotel_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image12.jpg" height="160" width="666" />
<div id="header2" class="grid_12">
<img src="image13.jpg" height="160" width="666" />
</div>

<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                             <h1>Bangladesh Hotels </h1>
							 <p>Need to find hotel accommodations in Bangladesh? No problem...
							 the discoverybangladesh.com hotel guide provides a 
							 good selection of Bangladeshi hotels to choose from.<br>
							 <br>
							 Just select the city and hotel below to get started.
							 Whether you are looking for a Bangladeshi luxury hotel
							 or a cheap city hotels, you'll be able to find and
							 book suitable hotels / accommodations in Bangladesh at great price.<br></p>
							 <br>
							 <tr> 
                             <td height="82"> 
                             <table width="100%" border="0">
                             <tr bgcolor="#E4E4D1"> 
                              <td colspan="2"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606  ">Hotels 
                              in Dhaka</font></font></b></font></td>
                             </tr>
                             <tr> 
                             <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">The 
                              Westin Dhaka<br>
                              Radisson Water Garden Hotel Dhaka<br>
                              Pan Pacific Sonargaon<br>
                              Dhaka Sheraton Hotel<br>
                              Lake Shore Hotel &amp; Apt<br>
                              Washington Hotel<br>
                              Hotel Sarina<br>
                              Asia Pacific Hotel<br>
                              Hotel Sweet Dream</font></td>
                              <td width="44%" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Royal 
                              Park Residence<br>
                              Best Western La Vinci Hotel<br>
                              Rose Wood Residence<br>
                              Sundarban Hotel<br>
                              Pacific Garnet Hotel<br>
                              Traveller Inn<br>
                              Hotel de Crystal Crown<br>
                              </font></td>
                             </tr>
                             </table>
                             </td>
                             </tr>
                             <tr> 
                             <td><img src="line-hotel-travel-bangladesh-cheap-hotels-in-bangladesh.gif" width="500" height="9"></td>
                             </tr>
							 <tr> 
							 <td> 
                             <table width="100%" border="0">
                             <tr> 
                             <td colspan="2" bgcolor="#E4E4D1"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606">Hotels 
                              in Chittagong</font></font></b></font></td>
                             </tr>
                             <tr> 
                             <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Seagull<br>
                              Hotel Shaibal<br>
                              Hotel Agrabad<br>
                              Asian SR Hotel<br>
                              Grand Park Hotel<br>
                              Hotel Golden Inn</font> </td>
                             <td width="44%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Tower Inn International<br>
                              Hotel Miskha<br>
                              Hotel Park Residential<br>
                              Meridian Hotel<br>
                              Peninsula Chittagong<br>
                              Silver Inn Hotel </font></td>
                             </tr>
                             </table>
                             </td>
                             </tr>
                             <tr> 
                             <td><img src="line-hotel-travel-bangladesh-cheap-hotels-in-bangladesh.gif" width="500" height="9"></td>
                             </tr>
                             <tr> 
                             <td> 
                             <table width="100%" border="0">
                             <tr bgcolor="#E4E4D1"> 
                             <td colspan="2"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606  ">Hotels 
                              in Cox's Bazar</font></b></font></td>
                             </tr>
                             <tr> 
                             <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Nitol 
                              Bay Resort<br>
                              Hotel Media International<br>
                              Hotel New United International<br>
                              </font></td>
                             <td width="44%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Panowa<br>
                              Hotel Coral Reef<br>
                              Sea Palace Hotel </font></td>
                             </tr>
                             </table>
                             </td>
                             </tr>
                             <tr> 
                             <td><img src="line-hotel-travel-bangladesh-cheap-hotels-in-bangladesh.gif" width="500" height="9"></td>
                             </tr>
                             <tr> 
                             <td height="82"> 
							 <table width="100%" border="0">
							 <tr> 
                             <td colspan="2" bgcolor="#E4E4D1"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606">Hotels 
                              in Khulna</font></font></b></font></td>
							 </tr>
							 <tr> 
                             <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Royal International<br>
                              Western Inn International <br>
                              Khulna Hotel<br>
                              Society Hotel<br>
                              Hotel Arcadia<br>
                              Hotel Babla<br>
                              Hotel Castle Salam </font></td>
                             <td width="44%" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Jalico<br>
                              Banchte Shekha, Jessore<br>
                              Grand Hotel, Jessore<br>
                              Hotel Hasan International, Jessore<br>
                              Hotel Magpie, Jessore<br>
                              Hotel Mid-Town, Jessore </font></td>
							 </tr>
							 </table>
							 </td>
							 </tr>
							 <tr> 
							 <td><img src="line-hotel-travel-bangladesh-cheap-hotels-in-bangladesh.gif" width="500" height="9"></td>
							 </tr>
							 <tr> 
							 <td> 
							 <table width="100%" border="0">
							 <tr bgcolor="#E4E4D1"> 
                             <td colspan="2"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606  ">Hotels 
                              in Sylhet</font></font></b></font></td>
                             </tr>
							 <tr> 
                             <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Dallas<br>
                              Hotel Fortune Garden<br>
                              Rose View Hotel<br>
                              Surma Valley Rest House<br>
                              Nirvana Inn<br>
                              Bangladesh Tea Research Institute Guesthouse, Srimangal 
                              </font></td>
                             <td width="44%" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Taj Mahal, Srimangal<br>
                              Hotel Tea Town, Srimangal<br>
                              Hotel United, Srimangal<br>
                              Nishorgo Eco-resort, Srimangal<br>
                              Tea Resort, Srimangal</font></td>
							 </tr>
							 </table>
							 </td>
							 </tr>
							 <tr> 
							 <td><img src="line-hotel-travel-bangladesh-cheap-hotels-in-bangladesh.gif" width="500" height="9"></td>
							 </tr>
							 <tr> 
							 <td> 
							 <table width="100%" border="0">
							 <tr bgcolor="#E4E4D1"> 
						     <td colspan="2"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606  ">Hotels 
                              in Barisal</font></font></b></font></td>
							 </tr>
							 <tr> 
							 <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Ababil<br>
                              Hotel Ali International<br>
                              <br>
                              </font></td>
                             <td width="44%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Athena International<br>
                              Paradise Hotel<br>
                              </font></td>
                             </tr>
							 </table>
							 </td>
							 </tr>
							 <tr> 
							 <td height="2"><img src="line-hotel-travel-bangladesh-cheap-hotels-in-bangladesh.gif" width="500" height="9"></td>
							 </tr>
							 <tr> 
							 <td height="2"> 
							 <table width="100%" border="0">
							 <tr bgcolor="#E4E4D1"> 
                             <td colspan="2"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><font size="4" color="#915606  ">Hotels 
                              in Rajshahi</font></font></b></font></td>
							 </tr>
							 <tr> 
                             <td width="56%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hotel 
                              Sukarna<br>
                              Hotel Dalas International<br>
                              Hotel Mukta<br>
                              Hotel Nice International<br>
                              Hotel Rajmahal<br>
                              </font></td>
                             <td width="44%"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Parjatan 
                              Hotel<br>
                              Haq's Inn<br>
                              Hotel Midtown<br>
                              Hotel Naz Garden, Bogra<br>
                              </font></td>
							 </tr>
							 </table>
							 </td>
							 </tr>
							 <tr> 
							 <td height="2">&nbsp;</td>
							 </tr>
							 <tr> 
							 <td height="2">&nbsp;</td>
							 </tr>
							 </table>
							 </td>
							 <td width="6%" valign="top" align="left" height="502"></td>
							 </tr>
						     </table>
							 </td>
							 </tr>
							 </table>

                           

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
