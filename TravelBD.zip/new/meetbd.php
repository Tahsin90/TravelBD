<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="meetbd_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image7.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                             <h1>Meet Bangladesh</h1>
							 
							    <tr> 
								<td width="9%" valign="top" align="left"></td>
								<td width="83%" valign="top" align="left"> 
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr> 
								<td width="100%"> 
								<p align="justify"><font size="1" > 
                                <font face="Verdana, Arial, Helvetica" size="2">
								<p align="justify"><b><font  color="#094B0B" face="Verdana, Arial, Helvetica, sans-serif" size="4">Geography 
                              of Bangladesh : Quick look</font></b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br>
                              <br>
                              <b><font color="#008000">Location:</font></b> Southern 
                              Asia, bordering the Bay of Bengal, between Burma 
                              and India.&nbsp;<br>
                              <br>
                              <b><font color="#008000">Geographic coordinates:</font></b> 
                              24 00 N, 90 00 E.<br>
                              <b><font color="#008000">Map references:</font></b> 
                              Asia&nbsp;<br>
                              <br>
                              <b><font color="#008000">Area:</font></b><br>
                              <font color="#008000">total:</font> 144,000 sq km.<br>
                              <font color="#008000">land:</font> 133,910 sq km.<br>
                              <font color="#008000">water:</font> 10,090 sq km.&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Area-comparative:</b></font> 
                              slightly smaller than Iowa.&nbsp;<br>
                              <font color="#008000"><b><br>
                              Land boundaries:</b></font><br>
                              <font color="#008000">total:</font> 4,246 km<br>
                              <font color="#008000">border countries:</font> Burma 
                              193 km, India 4,053 km&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Coastline: </b></font>580 
                              km.&nbsp;<br>
                              <b><font color="#008000">Maritime claims:</font></b><br>
                              <font color="#008000">contiguous zone:</font> 18 
                              nm.<br>
                              <font color="#008000">continental shelf: </font>up 
                              to the outer limits of the continental margin.<br>
                              <font color="#008000">exclusive economic zone:</font> 
                              200 nm.<br>
                              <font color="#008000">territorial sea:</font> 12 
                              nm.&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Climate:</b> </font>tropical; 
                              mild winter (October to March); hot, humid summer 
                              (March to June); humid, warm rainy monsoon (June 
                              to October)<br>
                              <br>
                              <font color="#008000"><b>Terrain: </b></font>mostly 
                              flat alluvial plain; hilly in southeast.&nbsp;<br>
                              <br>
                              <b><font color="#008000">Elevation extremes:</font></b><br>
                              <font color="#008000">lowest point:</font> Indian 
                              Ocean 0 m.<br>
                              <font color="#008000">highest point:</font> Keokradong 
                              1,230 m.&nbsp;<br>
                              <br>
                              <b><font color="#008000">Natural resources: </font></b>natural 
                              gas, arable land, timber.<br>
                              <br>
                              <b><font color="#008000">Land use:</font></b><br>
                              <font color="#008000">arable land:</font> 61%<br>
                              <font color="#008000">permanent crops:</font> 3%<br>
                              <font color="#008000">other: </font>36% (1998 est.)<br>
                              <br>
                              <font color="#008000"><b>Irrigated land:</b></font> 
                              38,440 sq km (1998 est.)<br>
                              <br>
                              <b><font color="#008000">Natural hazards:</font></b> 
                              droughts, cyclones; much of the country routinely 
                              flooded during the summer monsoon season.<br>
                              <br><br>
							  
							  
							  <p align="justify"><b><font color="#094B0B" face="Verdana, Arial, Helvetica, sans-serif" size="4">Bangladesh 
                              Economy : Quick look</font></b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br></font>
                              <br>
                              <font color="#008000"><b>GDP: </b></font>purchasing 
                              power parity - $230 billion (2001 est.)<br>
                              <b><font color="#008000">GDP-real growth rate: </font></b>5.6% 
                              (2001 est.)<br>
                              <font color="#008000"><b>GDP-per capita: </b></font>purchasing 
                              power parity - $1,750 (2001 est.)<br>
                              <font color="#008000"><b><br>
                              GDP-composition by sector:</b></font><br>
                              <font color="#008000">agriculture: </font>30%.<br>
                              <font color="#008000">industry:</font> 18%.<br>
                              <font color="#008000">services: </font>52% (2000).<br>
                              <br>
                              <font color="#008000"><b>Population below poverty 
                              line: </b></font>35.6% (1995-96 est.)&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Household income or consumption 
                              by percentage share:</b></font><br>
                              <font color="#008000">lowest </font><font color="#000000">10%:</font> 
                              3.9%.<br>
                              <font color="#008000">highest </font>10%: 28.6% 
                              (1996).<br>
                              <br>
                              <font color="#008000"><b>Inflation rate (consumer 
                              prices):</b></font> 5.8% (2000)&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Labor force:</b></font> 
                              64.1 million (1998).<br>
                              <font color="#008000">note: </font>extensive export 
                              of labor to Saudi Arabia, Kuwait, UAE, Oman, Qatar, 
                              and Malaysia; workers' remittances estimated at 
                              $1.71 billion in 1998-99.<br>
                              <br>
                              <font color="#008000">Labor force-by occupation:</font> 
                              agriculture 65%, services 25%, industry and mining 
                              10% (1996)&nbsp;<br>
                              Unemployment rate: 35.2% (1996).&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Budget:</b></font><br>
                              <font color="#008000">revenues:</font> $4.9 billion<br>
                              <font color="#008000">expenditures:</font> $6.8 
                              billion, including capital expenditures of $NA (2000).&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Industries: </b></font>jute 
                              manufacturing, cotton textiles, garments, tea processing, 
                              paper newsprint, cement, chemical, light engineering, 
                              sugar, food processing, steel, fertilizer.&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Industrial production growth 
                              rate: </b></font>6.2% (2001)<br>
                              <font color="#008000"><b>Electricity-production: 
                              </b></font>13.493 billion kWh (2000).<br>
                              <font color="#008000"><b><br>
                              Electricity-production by source:</b></font><br>
                              <font color="#008000">fossil fuel:</font> 92.45%<br>
                              <font color="#008000">hydro:</font> 7.55%<br>
                              <font color="#008000">nuclear:</font> 0%.<br>
                              <font color="#008000">other: </font>0% (2000).<br>
                              <br>
                              <b><font color="#008000">Electricity-consumption:</font></b> 
                              12.548 billion kWh (2000)<br>
                              <b><font color="#008000">Electricity-exports:</font></b> 
                              0 kWh (2000).<br>
                              <b><font color="#008000">Electricity-imports: </font></b>0 
                              kWh (2000).<br>
                              <br>
                              <font color="#008000"><b>Agriculture-products:</b></font> 
                              rice, jute, tea, wheat, sugarcane, potatoes, tobacco, 
                              pulses, oilseeds, spices, fruit; beef, milk, poultry.<br>
                              <br>
                              <b><font color="#008000">Exports: </font></b>$6.6 
                              billion (2001)<br>
                              <br>
                              <b><font color="#008000">Exports-commodities: </font></b>garments, 
                              jute and jute goods, leather, frozen fish and seafood.<br>
                              <br>
                              <font color="#008000"><b>Exports-partners:</b></font> 
                              US 31.8%, Germany 10.9%, UK 7.9%, France 5.2%, Netherlands 
                              5.2%,&nbsp;<br>
                              Italy 4.42% (2000).<br>
                              <br>
                              <font color="#008000"><b>Imports:</b></font> $8.7 
                              billion (2001)<br>
                              <br>
                              <font color="#008000"><b>Imports-commodities:</b></font> 
                              machinery and equipment, chemicals, iron and steel, 
                              textiles, raw cotton, food, crude oil and petroleum 
                              products, cement.<br>
                              <br>
                              <font color="#008000"><b>Imports-partners:</b></font> 
                              India 10.5%, EU 9.5%, Japan 9.5%, Singapore 8.5%, 
                              China 7.4% (2000)<br>
                              <br>
                              <font color="#008000"><b>Economic aid-recipient:</b></font> 
                              $1.575 billion (2000 est.)<br>
                              <br>
                              <font color="#008000"><b>Currency: </b></font>1 
                              taka (Tk) = 100 poisha.<br>
                              <br>
                              <font color="#008000"><b>Exchange rates:</b></font> 
                              Taka per US dollar - 57.756 (January 2002), 55.807 
                              (2001), 52.142 (2000), 49.085 (1999), 46.906 (1998), 
                              43.892 (1997)<br>
                              <br>
                              <font color="#008000"><b>Fiscal year:</b></font> 
                              1 July-30 June.</font> <br>
                              <br>
							  <br>
							  
							  
							  <p align="justify"><b><font color="#094B0B" face="Verdana, Arial, Helvetica, sans-serif" size="4">	
                              Government of Bangladesh [Quick Look]
                              </font></b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br></font>
                              <br>
							  <b><font color="#008000">Country Name:</font></b><br>
                              <font color="#008000">conventional long form: </font>People's 
                              Republic of Bangladesh.<br>
                              <font color="#008000">conventional short form:</font> 
                              Bangladesh.<br>
                              <br>
                              <br>
                              <b><font color="#008000">Data code: </font></b>BG.&nbsp;<br>
                              <font color="#008000"><b>Government type: </b></font>Republic.<br>
                              <b><font color="#008000">Capital: </font></b>Dhaka.&nbsp;<br>
                              <br>
                              <font color="#008000"><b>Administrative divisions:</b></font> 
                              7 divisions; Barisal, Chittagong, Dhaka, Khulna, 
                              Rajshahi, Sylhet &amp; Rangpur.<br>
                              <br>
                              <b><font color="#008000">Independence: </font></b>26 
                              March 1971 (from Pakistan).<br>
                              <b><font color="#008000"><br>
                              National holiday:</font></b> Independence Day - 
                              26 March (1971), 16 December 1971 is Victory Day 
                              and commemorates the official creation of the state 
                              of Bangladesh, 21st February and more.<br>
                              <br>
                              <b><font color="#008000">Constitution: </font></b>4 
                              November 1972, effective 16 December 1972, suspended 
                              following coup of 24 March 1982, restored 10 November 
                              1986, amended many times.&nbsp;<br>
                              <br>
                              <b><font color="#008000">Legal system: </font></b>based 
                              on English common law.<br>
                              <br><br>
							  
							  
							  
							  <p align="justify"><b><font color="#094B0B" face="Verdana, Arial, Helvetica, sans-serif" size="4"> 
                              Bangladesh : Land, Resources & Natural Regions</font></b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><br></font>
                              <br>
							  <b><font color="#008000">Land&nbsp;</font></b><br>
                              <font color="#008000">Total area:</font> 144,000 
                              square kilometers;<br>
                              <font color="#008000">Land area: </font>133,910 
                              square kilometers<br>
                              <font color="#008000">Land boundaries:</font> 4,246 
                              km total; 193 km with Myanmar, 4,053 km with India,&nbsp;<br>
                              Coastline: 580 km.<br>
                              <br>
                              <b><font color="#008000">Land distribution:&nbsp;</font></b><br>
                              <font color="#008000">· arable land 67%&nbsp;<br>
                              · forest and woodland 16%&nbsp;<br>
                              · permanent crops 2%&nbsp;<br>
                              · meadows and pastures 4%&nbsp;<br>
                              · others 11%</font></font> <br>
                              <br>
							  
                            </font> 
                            </td>
                            </tr>
							</table>
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left"> &nbsp;&nbsp;&nbsp; 
							</td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							<tr> 
							<td width="9%" valign="top" align="left"></td>
							<td width="83%" valign="top" align="left">&nbsp; </td>
							<td width="9%" valign="top" align="left"></td>
							</tr>
							</table>

                           

	</div>
	<div id="footer" >
	
	 <ul>
<<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
