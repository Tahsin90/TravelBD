<?php
	include 'config.php';
	if(isset($_GET['id'])){
		$id = $_GET['id'];
	}
	if(isset($_GET['price'])){
		$price = $_GET['price'];
	}
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
            <h3>Package Details</h3>
			<p>
				
				<?php 
				$sql = "SELECT `id`, `details` FROM `package` WHERE id= $id ";
				$query_result = mysqli_query($conn,$sql) or die(mysql_error());
				if(mysqli_num_rows($query_result) > 0)
				{
					
					while ($row = mysqli_fetch_array($query_result))
					{?>
						<?php echo $row['details']; ?>
						
					<?php
					}
				}
			?>  
			</p><br>
			<h3>For Reservation</h3><br>
		<form method="post" action="thankyou.php">
		<p id="name1">
	      <label for ="name">Your Name : </label>
	      <input type="text" name="name" id="name" />
	   
	   </p><br>
	   
	   <p id="name">
	      <label for ="email">Your email address :</label>
	      <input type="text" name="email" id="email" />
	   
	   </p><br>
	   
	    <p id="contact">
	      <label for ="contact">Contact No :</label>
	      <input type="text" name="contact" id="contact" />
	   </p>
		<label>
		<br><br>How many persons : 
		</label>
		<select name="person">
		   <option>1</option>
		   <option>2</option>
		   <option>3</option>
		   <option>4</option>
		   <option>5</option>
		   <option>6</option>
		   <option>7</option>
		   <option>8</option>
		</select>
		<?php echo '*' . $price ;?>
		<br><br><br>
		<input type="hidden" name="packageId" value="<?php echo $id; ?>">
		<input type="hidden" name="price" value="<?php echo $price; ?>">
			<input type= "submit" value= "submit">
		</form>	
		
	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
