<?php
session_start();
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>

<html>
<head>
 <link rel="stylesheet" type="text/css"
          href="register_style.css" />
</head>
<body>

<div class="container">
    <h2>Create a New Account</h2>
    <?php echo !empty($statusMsg)?'<p class="'.$statusMsgType.'">'.$statusMsg.'</p>':''; ?>
    <div class="regisFrm">
	
	    
        <form  action="userAccount.php" method="post">
		    <tr><td>First Name : </td></tr><br>
            <input type="text" name="first_name" placeholder="FIRST NAME" required=""><br>
			<tr><td>Last Name : </td></tr><br>
            <input type="text" name="last_name" placeholder="LAST NAME" required=""><br>
			<tr><td>Email : </td></tr><br>
            <input type="email" name="email" placeholder="EMAIL" required=""><br>
			<tr><td>Phone No : </td></tr><br>
            <input type="text" name="phone" placeholder="PHONE NUMBER" required=""><br>
			<tr><td>Password: </td></tr><br>
            <input type="password" name="password" placeholder="PASSWORD" required=""><br>
			<tr><td>Confirm Password : </td></tr><br>
            <input type="password" name="confirm_password" placeholder="CONFIRM PASSWORD" required=""><br>
            <div class="send-button">
                <br><input action="tourpackage.php" type="submit" name="signupSubmit" value="CREATE ACCOUNT">
            </div>
        </form>
    </div>
</div>
</body>
</html>