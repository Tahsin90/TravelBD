<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Barishal Division</h1><br>
			   <h4>BARISHAL DIVISION</h4>
			   <p>
			 		Barisal division is in the south west part of Bangladesh, 
					has an area of 13297 sq. km and a population of 8.11 million.
					There are 6 districts and 22 municipalities under Barisal. It
					is a revering area. Barishal is a Division of rivers and 
					canals. It is also famous for gardens of coconut trees. 
					You will find thousands of coconut trees throughout Barishal
					Division. Kuakata is the main tourist spot in the division. 
					In Barishal town you can visit Durga Sagor - a beautiful Dighi
					where lot of guest birds comes every winter season. This is also 
					a beautiful park where you can spend your leisure time by roaming around the park and watching the birds.
			   </p>
			   
			   <p>
			   There exists road communication between Dhaka 
			   and Patuakhali district headquarters. Accessible by
			   road, water or air transport up to Barisal. 
			   Then one may travel by road or water to Kuakata 
			   or Patuakhali. From Dhaka you can go to Patuakhali 
			   by bus & from there by microbus to Kuakata. It is 
			   advisable to go Patuakhali by launch, which is an 
			   overnight journey, and you can enjoy the unique beauty 
			   of Bangladesh Rivers at nighttime during this journey. 
			   Instead of Potuakhali you can go to Khepupara by launch,
			   which is also an overnight journey and from Khepupara you 
			   can go to Kuakata by microbus. A direct BRTC bus service is
			   also available from Dhaka to Kuakata that leaves from Sayedabad Bus 
			   terminal at night takes 12 hours to reach Kuakata. But it might be a
			   hectic bus journey as a number of ferries are there on the way to
			   Kuakata by road. BRTC has introduced direct bus service from Dhaka to Kuakata via Barisal.
			  
			   </p>
			   
			   <h4>Where To Stay :</h4>
			   <p>
			   There are some hotel and motels in Kuakata where you can stay, 
			   but Holiday Homes is the best place to stay in Kuakata. 
			   It is a motel of Bangladesh Parjatan Corporation and its
			   better if you confirm your booking from Dhaka in advance.
			   </p><br>
			   
			   
			   

			   
			   
			   
			   <h3>Main Tourist Spots In Barishal Division:</h3>
			   
			   <p>
			   Kuakata (Patuakhali) - Kuakata Beach - Durga sagar (Barisal City) - Lebur Char (Latachapli) - Guthia Mosque (Barisal City) - Kuakata Buddhist Temple (Kuakata) 
			   - Jhau Forest (Kuakata) - Sonar Char - Guava Market (Barisal City) - Gangamati Reserved Forest (Kuakata)
			   </p>
			  
			   

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>


<?php
	include 'close.php';
?>