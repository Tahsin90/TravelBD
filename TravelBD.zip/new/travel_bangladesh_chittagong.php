<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Chittagong Division</h1><br>
			   <h4>Chittagong DIVISION</h4>
			   <p>
                Chittagong Division is located at southern part of the country has an area of 33771 sq. km and a population of 23.99. It has 11 districts and 38 municipalities. 

                Chittagong is the biggest seaport and second largest town in Bangladesh situated near the Bay of Bengal. It is 264 km away east of Dhaka, famous for hill areas, natural beauty and for the seashore. Chittagong is also known of the town of Aulias (Muslim saints).
			   </p>
			
			   <p>
			   Its green hills and forests, its broad sandy beaches and its fine cool climate always attract the holiday-markers. Described by the Chinese traveler poet, Huen Tsang (7th century A.D) as "a sleeping beauty emerging from mists and water" and given the title of "Porto Grande" by the 16th century Portuguese seafarers..</p>
			   <p>
			   Chittagong combines remains true to both the descriptions even today. It combines the busy hum of an active seaport with the shooting quiet of a charming hill town.
			   </p>
			   <p>
			   The Shahi Jama-e-Masjid and Qadam Mubarak Mosque are two of the most impressive buildings in the city. It is also worth visiting the Ethnological Museum in the Modern City, which has interesting displays on Bangladesh's tribal peoples. There are good views and cooling breezes from Fairy Hill in the British City in the northwestern sector of the city.
Chittagong is the country's chief port and is the main site for the establishment of heavy, medium and light industries. Bangladesh's only steel mill and oil refinery are also located in Chittagong. 
			   </p>
			   <br>
			   
			   <h3>Main Tourist Spots In Chittagong Division:</h3>
			   
			   <h4>Inside Chittagong City:</h4>
			   <p>
			    War Cemetery - Zia memorial Museum - Ethnological Museum - Court Building Museum - Shrine's - Fays Lake - Patenga & Fouzdarhat - Port Area
			   </p>
			   <br>
			   <h4>Outside Chittagong City:</h4>
			   <p>
			   Sitakundu - Parki Beach - Chandraghona - Cox's Bazar - Himchori & Inani Beach - Moheshkhali Island - Sonadia Island - St. Martins Island - Nijhum Island - Aggameda Khyang - Ramu - Teknaf - Comilla - BARD - Lalmai & Moinamoti - Hill tracks >> Rangamati - Khagrachari - Bandarban 
			   </p>
			   

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>