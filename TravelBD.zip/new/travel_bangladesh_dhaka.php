<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Dhaka Division</h1><br>
			   <h4>DHAKA DIVISION</h4>
			   <p>
			   Dhaka division is located at center of the country 
			   has an area of 31119 sq. km and a population of 38.678 million.
			   It has 17 districts and 64 municipalities. Main rivers of this
			   division are padma, jamuna, meghna, old brahmaputra, dhaleshwari,
			   shitalakshya, brahmaputra, buriganga, arial khan. Madhupur and Bhawal
			   Garhs are located to the northern parts of Dhaka, in Gazipur, 
			   southern part of Mymensingh and eastern part of Tangail districts;
			   Garo hills are located in Mymensingh district. Dhaka (Capital City)
			   stands on the bank of the river Buriganga. 
			   </p><br>
			   
			   <h4>DHAKA CITY</h4>
			   <p>
			   Dhaka is the capital of Bangladesh. The city is known as 
			   the city of mosque, muslin and rickshaws. It has attracted
			   travellers from far and near through ages. Dhaka as the 
			   capital of Bangladesh has grown into a busy city of about 
			   ten million people with an area of about 1353 sq. km. Having 
			   a happy blending of old and new architectural trends, Dhaka
			   has been developing fast as a modern city and is throbbing 
			   with activities in all spheres of life. It is the center of 
			   industrial, commercial, cultural, educational and political 
			   activities for Bangladesh.</p><br>
			   
			   <h3>Main Tourist Spots In Dhaka Division:</h3>
			   
			   <h4>Inside Dhaka City:</h4>
			   <p>
			   Ahsan Manjil - Lalbag Fort - National Museum - Bangabandhu Memorial - Mukti Juddha Museum - Science Museum - Shadhinota Stambha - National Poet's Graveyard - Suhrawardy Uddyan - National Leader Mausoleum - Banga-Bhaban - Ramna Park - Parliament House - Arts & Crafts Institute - Curzon Hall - Old High Court - 1857 Memorial - National Zoo - Botanical Garden - Baldha Garden - Star Mosque - Baitul Mukarram Mosque - Mosques - Hindu Temples - Churches
			   </p>
			   <br>
			   <h4>Outside Dhaka City:</h4>
			   <p>
			   Mosque Of Baba Adam - Sonargaon - National Martyrs Memorial - Bhawal National Park - Jamuna Bridge - Tungipara - Modhupur Picnic Spot - Susang Durgapur - Gajni Parjatan Center
			   </p>
			   

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBDExplorebd.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>
