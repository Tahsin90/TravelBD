<?php
	include 'config.php';
	
?>


<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Khulna Division</h1><br>
			   <h4>KHULNA DIVISION</h4>
			   <p>
                 Khulna division is in the southwest part of 
				 Bangladesh has an area of 22274 sq. km and a 
				 population of 14.47 million. There are 10 districts
				 and 28 municipalities under Khulna. It has the world's
				 biggest mangrove forest, the Sundarbans. In Khulna town 
				 you can visit Khulna Museum and Zoo.
			   </p>
			
			   <p>
			   Sundarban is the world biggest mangrove forest. 
			   In Bangladesh tourism, Sunderban plays the most 
			   vital role. A large number of foreigners come to 
			   Bangladesh every year only to visit this unique
			   mangrove forest. Besides, local tourists also go
			   to visit Sundarban every year. The area of great 
			   Sundarban is approximately 6000 sq. km.
			   <p>
			   Only means of transportation inside the forest is boat. 
			   There is no road, no trail of a path anywhere. 
			   The woodcutters make temporary dwellings at the
			   edge of the forest at a height of 8-10 feet for 
			   fear of wild animals others live on boats. In the 
			   chandpai region it is fascinating to see the nomadic 
			   fishermen (living with families on boats) catching fish 
			   with the help of trained offers. Exciting activities take
			   </p><br>

			   <h3>Main Tourist Spots In Khulna Division:</h3>
			   
			   <h4>Inside Khulna City:</h4>
			   <p>
			    Sundarban - karamjal- Katka - Hiran Point- Shat Gombuj Mosque- Candramahal - Khan Jahan Ali Majar - Nalta Sharif - Rupsha Bridge
			   </p>
			   <br>
			   <h4>Outside Khulna City:</h4>
			   <p>
			   Shrine of Lalon Shah - Kuthibari - Madhu kunj - Chachra Shiv Mandir - Ronvijoypur Mosque - St Paul’s Catholic Church -Nine-Domed Mosque -Singar Mosque

			   </p>

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>