<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Rajshahi Division</h1><br>
			   <h4>RAJSHAHI DIVISION</h4>
			   <p>
			 	Rajshahi division is in the northern part of 
				Bangladesh has an area of 34513 sq. km and a population 
				of 29.99 million. There are 16 districts and 57 municipalities 
				under Rajshahi. It is famous for archeological and historical sites.
			   </p><br>
			   
			   <h4>RAJSHAHI CITY</h4>
			   <p>
			   Rajshahi town is situated besides the river Padma. In monsoon the great
			   Padma is in full spate with its tides and waves whereas in winter it 
			   dwindles and you will feel the desert by the side of river. Rajshahi 
			   Division is famous for archeological and historical places like Mohastnangor,
			   Paharpur Buddhist Monastery, Kantajee’s Temple, Ramshagar Dighi, Choto Sona 
			   Masjid, and Shopnopuri etc. You can visit Rajshahi University. It’s a very 
			   well planed University and you can visit The Shahid Smriti Sangraha Shala 
			   in the University, you can see the documents and photography’s from the 
			   language movement of 1952 to the liberation was 1972. You can also visit 
			   Borendra Research Museum. There you will find the ancient elements of 
			   Paharpur, Mohasthangar and Mohenjodaro. 
			   </p><br>
			 

			   
			   
			   
			   <h3>Main Tourist Spots In RAJSHAHI Division:</h3>
			   
			   <p>
			   Mahasthangarh - Paharpur Buddhist Monastery - Kantajee's Temple - Ramshagor Dighi - Shopnopuri - Choto Sona Mosque - Varendra Research Museum - Puthia
			   </p>
			  
			   

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>