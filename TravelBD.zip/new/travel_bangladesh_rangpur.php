<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Rangpur Division</h1><br>
			   <h4>RANGPUR DIVISION</h4>
			   <p>
			 	Under the Rangpur division (one of seven divisions) composed 
				of eight districts of the northern Bangladesh, the District 
				of Rangpur is bordered on the north by Nilphamari District,
				on the south by Gaibandha District, on the east by Kurigram,
				and on the west by Dinajpur district. Rangpur town is the divisional 
				headquarter. The soil composition is mainly alluvial soil (80%) of the
				Teesta River basin, and the remaining is barind soil. The temperature 
				ranges from 32 degrees Celsius to 11 degrees Celsius, and the annual 
				rainfall averages 2931 mm
			   </p><br>
			   
			   
			   <h4>RANGPUR CITY</h4>
			   <p>
			   Rangpur is one of the newly established City Corporations of the 
			   country. Apart from the status of a City Corporation it is the 
			   administrative headquarters of the Rangpur Division comprising 
			   the old greater Rangpur and Dinajpur districts. The attractive 
			   central location and the seat of an age old administrative centre
			   dating back to the early days of British rule, Rangpur has the 
			   potential to develop not only as an administrative centre but 
			   also as an economically vibrant area housing substantial urban 
			   population of the country (Map 1.1 shows the location of Rangpur 
			   City in the national context).  
			   </p>
			   <p>
			  Rangpur is one of the major cities in Bangladesh and Rangpur Division. 
			  Rangpur was declared a district headquarters on 16 December 1769, 
			  and established as a municipality in 1869, making it one of the 
			  oldest municipalities in Bangladesh.[1][4] The municipal office 
			  building was erected in 1892 under the precedence Raja Janaki Ballav, 
			  Sen. Chairman of the municipality. During the period of 1890, "Shyama
			  sundari khal" was excavated for improvement of the town. The Municipality
			  is located in the north western part of Bangladesh.[1] A Recently established public
			  university of Bangladesh named "Begum Rokeya University, Rangpur" is situated in the 
			  southern part of the city. Previously, Rangpur was the headquarters of Greater Rangpur
			  district. Later the Greater Rangpur district was broken down into the Rangpur, Kurigram,
			  Nilphamari, Lalmonirhat and Gaibandha districts. In the great Rangpur region,
			  little economic development took place until the 90s, mainly because of the yearly
			  flooding the region used to see before the making of the Teesta Barrage. Coal is
			  found near this district. There is a large military cantonment in the town. 
			   </p><br>
			   
			   

			   
			   
			   
			   <h3>Main Tourist Spots In Rangpur Division:</h3>
			   
			   <p>
			   Tajhat Palace - Rangpur zoo - Mural of Bangabondhu - Indira Moor - Vinnojogot - Sopnopur - Tajbari Museum - Chicli Vata - 
			   Raipur Zamindar  Palace - Rajbari
			   </p>
			  
			   

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>
     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>