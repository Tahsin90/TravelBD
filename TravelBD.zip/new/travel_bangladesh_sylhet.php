<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
               <h1>	Destination Bangladesh :: Shylet Division</h1><br>
			   <h4>SHYLET DIVISION</h4>
			   <p>
			 	Sylhet division occupies the north east part 
				of Bangladesh, has an area of 12596 sq. km and
				a population of 7.899 million. There are 4 
				districts and 14 municipalities under Barisal.
				It is a natural hilly, forest area with ox bow
				lakes and famous shrines.
			   </p><br>
			   
			   <h4>SHYLET CITY</h4>
			   <p>
			   Nestled in the picturesque Surma 
			   Valley amidst scenic tea plantations and lush
			   green tropical forests, greater Sylhet is a 
			   prime attraction for all tourists visiting Bangladesh. 
			   Laying between the Khasia and the Jaintia hills on the
			   north, and the Tripura hills on the south, Sylhet breaks 
			   the monotony of the flatness of this land by a multitude
			   of terraced tea gardens, rolling countryside and the exotic 
			   flora and fauna. Here the thick tropical forests abound with 
			   many species of wildlife, spread their aroma around the typical 
			   hearth and homes of the Mainpuri Tribal maidens famous for their dance. 
			   </p>
			   The Sylhet valley is formed by a beautiful, winding pair of rivers named 
			   the Surma and the Kushiara both of which are fed by innumerable hill streams
			   from the north and the south. The valley has good number of haors, which are
			   big natural depressions. During winter these haors are vast stretches of 
			   green land, but in the rainy season they turn into turbulent seas. 
			   <p>
			   These haors provide a sanctuary to the millions of migratory birds who
			   fly from Siberia across the Himalayas to avoid the severe cold there. 
			   Sylhet has also a very interesting and rich hilstory, Before the conquest 
			   by the Muslims, it was ruled by local chieftains. In 1303, the great Saint
			   Hazrat Shah Jalal came to Sylhet from Delhi with a band of 360 disciples to
			   preach Islam and defeated the then Raja Gour Gobinda. 
			   </p>
			   Sylhet thus became a district of saints, shrines and
			   daring but virile people. Its rich potentialities became
			   easily attractive and the 18th century Englishmen made 
			   their fortune in tea plantation. About 80 km. from Sylhet 
			   town connected by road and rail, Srimangal, which is known 
			   as the tea capital of Bangladesh, is the actual tea center 
			   of the area.
			   <br>

			   
			   
			   
			   <h3>Main Tourist Spots In Shylet Division:</h3>
			   
			   <p>
			   The Shrine of Hazrat ShahJalal - Sri Chaitannya Dev Temple - Shahi Eidgah - Gour Gobinda Fort - Jaflong - Tamabil - Sripur - Jointapur's Rajbari - Srimongol - Madhabkunda Waterfall - Lawacherra Rain Forest - Handicrafts of Sylhet - Manipuri Dance
			   </p>
			  
			   

                               
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>