<?php
	include 'config.php';
	
?>

<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="travelbangladesh_style.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image11.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbd.php">Home</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>

</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">

                            <p>Bangladesh - A south asian country which is Lying north of 
							  the Bay of Bengal. iT has a total area of 147570 sq .km and population 
							  is about 164 million. On land it borders India in the north and west & Myanmar in the southeast. 
                            <br>
                            <br>
                                Bangladesh is subdivided into 7 divisions, all named after their respective capitals. These are:<br>
                            <br>
                            </p>
							<p>
							<p><font face="Verdana, Arial, Helvetica, sans-serif" size="2">* 
                          <a href="travel_bangladesh_dhaka.php">Dhaka Division</a> 
                          * <a href="travel_bangladesh_chittagong.php">Chittagong 
                          Division</a> * <a href="travel_bangladesh_khulna.php">Khulna 
                          Division</a> <br>
                          * <a href="travel_bangladesh_sylhet.php">Sylhet Division</a> 
                          * <a href="travel_bangladesh_rajshahi.php">Rajshahi 
                          Division</a> * <a href="travel_bangladesh_barishal.php">Barishal 
                          Division</a><br>
						  &amp; * <a href="travel_bangladesh_rangpur.php">Rangpur 
                          Division</a><br>
                          <br>
                          </font></p>
						</td>
						</tr>
						<tr> 
						<td height="82"> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow">
                          <tr> 
                            <td colspan="3"> </td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_dhaka.php"><img src="Dhaka-Division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="305" valign="top" height="13"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><a href="travel_bangladesh_dhaka.php"><font size="2" color="#333333">Dhaka 
                              Division</font></a></font></b></font></td>
                            <td align="right" width="69" height="13">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="305" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">With 
                              an area of 31119.97 sq km, is bounded by barisal 
                              and chittagong divisions on the south, sylhet and 
                              Chittagong Divisions on the east, rajshahi and khulna 
                              divisions on the west. Main Tourist Spots ..</font></td>
                            <td align="right" width="69" valign="bottom"><a href="travel_bangladesh_dhaka.php"><img src="more_info.gif" width="77" height="13" border="0"></a></td>
                          </tr>
                        </table>
						</td>
						</tr>
						<tr> 
						<td><img src="line_visit-bangladesh-inbound-tour-bangladesh-travel.gif" width="500" height="9"></td>
						</tr>
						<tr> 
						<td> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow" height="53">
                          <tr> 
                            <td colspan="3"></td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_chittagong.php"><img src="Chittagong-division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="304" valign="top"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><a href="travel_bangladesh_chittagong.php"><font size="2" color="#333333">Chittagong 
                              Division</font></a></font></b></font></td>
                            <td align="right" width="77">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="304" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">The 
                              most southern areas of Bangladesh with Hills and 
                              Sea. Enjoy the longest sea beach of Cox&#146;s bazar, 
                              the beauty of hills and rivers in Rangamati, Khagrachori 
                              &amp; Bandarban. Buddhist heritages ..</font></td>
                            <td align="right" width="77" valign="bottom"><a href="travel_bangladesh_chittagong.php"><img src="more_info.gif" width="77" height="13" border="0"></a></td>
                          </tr>
                        </table>
						</td>
						</tr>
						<tr> 
						<td><img src="line_visit-bangladesh-inbound-tour-bangladesh-travel.gif" width="500" height="9"></td>
						</tr>
						<tr> 
						<td> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow">
                          <tr> 
                            <td colspan="3"> </td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_khulna.php"><img src="Khulna-Division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="297"><font face="Arial, Helvetica, sans-serif" size="1"><b> 
                              <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="travel_bangladesh_khulna.php"><font color="#333333">Khulna 
                              Division</font></a></font></b></font></td>
                            <td align="right" width="77">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="297" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Khulna 
                              Division is famous for the Great Sundarban - world 
                              largest Mangrove forest &amp; the home of Royal 
                              Bengal tigers. Also visit Shat Gambuj Mosque, Shrine 
                              of Hajrat Khan Jahan Ali, Mongla ..</font></td>
                            <td align="right" width="77" valign="bottom"><a href="travel_bangladesh_khulna.php"><img src="more.jpg" width="77" height="13" border="0"></a></td>
                          </tr>
                        </table>
						</td>
						</tr>
						<tr> 
						<td><img src="line_visit-bangladesh-inbound-tour-bangladesh-travel.gif" width="500" height="9"></td>
						</tr>
						<tr> 
						<td height="82"> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow">
                          <tr> 
                            <td colspan="3"> </td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_sylhet.php"><img src="Sylhet-Division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="304" valign="top"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><a href="travel_bangladesh_sylhet.php"><font size="2" color="#333333">Sylhet 
                              Division</font></a> </font></b></font></td>
                            <td align="right" width="77">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="304" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Sylhet 
                              Division is known for its tea-gardens &amp; natural 
                              resources. Miles of Beautiful greenish view of tea 
                              plants attract a huge number of tourists. Sylhet 
                              is also famous for Shrines, Waterfall ..</font></td>
                            <td align="right" width="77" valign="bottom"><a href="travel_bangladesh_sylhet.php"><img src="more_info.gif" width="77" height="13" border="0"></a></td>
                          </tr>
                        </table>
						</td>
						</tr>
						<tr> 
						<td><img src="line_visit-bangladesh-inbound-tour-bangladesh-travel.gif" width="500" height="9"></td>
						</tr>
						<tr> 
						<td> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow">
                          <tr> 
                            <td colspan="3"></td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_rajshahi.php"><img src="Rajshahi-Division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="304" valign="top"><font face="Arial, Helvetica, sans-serif" size="1"><b><font face="Verdana, Arial, Helvetica, sans-serif"><a href="travel_bangladesh_rajshahi.php"><font size="2" color="#333333">Rajshahi 
                              Division</font></a></font></b></font></td>
                            <td align="right" width="77">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="304" valign="top" height="51"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Rajshahi 
                              Division is famous for Historical and archeological 
                              sites like Mohasthangar, Kantajee&#146;s Temple, 
                              Paharpur - great Buddhist heritage. Also well-known 
                              for its fruit, specially mangos ..</font><font face="Arial, Helvetica, sans-serif" size="1"> 
                              </font></td>
                            <td align="right" width="77" valign="bottom" height="51"><a href="travel_bangladesh_rajshahi.php"><img src="more_info.gif" width="77" height="13" border="0"></a></td>
                          </tr>
                        </table>
						</td>
						</tr>
						<tr> 
						<td><img src="line_visit-bangladesh-inbound-tour-bangladesh-travel.gif" width="500" height="9"></td>
						</tr>
						<tr> 
						<td> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow">
                          <tr> 
                            <td colspan="3"> </td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_barishal.php"><img src="Barishal-Division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="304" valign="top"><font face="Arial, Helvetica, sans-serif" size="1"><b> 
                              <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="travel_bangladesh_barishal.php"><font color="#333333">Barishal 
                              Division</font></a></font></b></font></td>
                            <td align="right" width="77">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="304" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">South 
                              west part of Bangladesh. A Division of rivers and 
                              cannels. Main tourist spot is Kuakata - A Truly 
                              Virgin Beach. Other tourist spots of Barishal Division 
                              are - Horinghata ..</font></td>
                            <td align="right" width="77" valign="bottom"><a href="travel_bangladesh_barishal.php"><img src="more_info.jpg" width="77" height="13" border="0"></a></td>
                             
                           </tr>
						  
						  
						  
                        </table>
						</td>
						</tr>
						<tr> 
						<td><img src="line_visit-bangladesh-inbound-tour-bangladesh-travel.gif" width="500" height="9"></td>
						</tr>
					
					                    <tr> 
						<td> 
                        <table width="100%" border="0" cellpadding="2" cellspacing="0" dwcopytype="CopyTableRow">
							<tr> 
                            <td colspan="3"> </td>
                          </tr>
                          <tr> 
                            <td rowspan="2" width="114"><a href="travel_bangladesh_rangpur.php"><img src="rangpur-Division-Bangladesh.jpg" width="112" height="70" border="1"></a></td>
                            <td width="304" valign="top"><font face="Arial, Helvetica, sans-serif" size="1"><b> 
                              <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="travel_bangladesh_barishal.php"><font color="#333333">Rangpur
                              Division</font></a></font></b></font></td>
                            <td align="right" width="77">&nbsp;</td>
                          </tr>
                          <tr> 
                            <td width="304" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
                              Rangpur Division was formed on 25 January 2010,  
							  as Bangladesh's 7th division. Before that,
							  it had been the northern eight districts
							  of the Rajshahi Division. The Rangpur 
							  division consists of eight districts. ..</font></td>
                            <td align="right" width="77" valign="bottom"><a href="travel_bangladesh_rangpur.php"><img src="more_info.jpg" width="77" height="13" border="0"></a></td>
                             
                           </tr>
						  
						  
						  
                        </table>
						</td>
						</tr>
						<tr> 
						<td height="2">&nbsp;</td>
						</tr>
						</table>
						</td>
						<td width="10%" valign="top" align="left" height="502"></td>
						</tr>
						</table>
						</td>
						</tr>
						</table>

							   
							   </p>
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="distance.php">Distance Chart</a></li>
<li><a href="Transportation.php">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>