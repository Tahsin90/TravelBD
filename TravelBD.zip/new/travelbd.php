<?php
	include 'config.php';
	
?>



<html>
<head>
<title>TravelBD</title>
<link rel="stylesheet" type="text/css"
href="styles.css" />
<style>See the right hand page</style>
</head>
<body>
<div id="header" class="grid_12">
<img src="image3.jpg" height="400" width="1332" />
<div id="nav">
<ul>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</div>
</div>

      <div id="sideleft" >
	  <h2>TravelBD</h2>
	  
 <ul>
	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="distance.php">Distance chart</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>
     </ul>

       </div>

<div class="main">
<h1>TravelBD - The Bangladesh Travel Guide</h1>
                              <p>Bangladesh 
                                is one of the few countries in South Asia, which 
                                remains to be explored. Bangladesh has a delicate 
                                and distinctive attraction of its own to offer 
                                and it is definitely not a tourist haunt like 
                                Nepal or India. Bangladesh is like a painter's 
                                dream come true with a rich tapestry of colors 
                                and texture. The traditional emphasis of the tourist 
                                trade has always been on the material facilities 
                                offered by a country rather than on its actual 
                                charms. This may be a reason why Bangladesh has 
                                seldom been highlighted in the World's tourist 
                                maps.<br>
                                <br>
                                It's a land of enormous beauty, hundreds of serpentine 
                                rivers, crystal clear water lakes surrounded by 
                                ever green hills, luxuriant tropical rain forests, 
                                beautiful cascades of green tea gardens, world's 
                                largest mangrove forest preserved as World Heritage, 
                                home of the Royal Bengal Tiger and the wild lives, 
                                warbling of birds in green trees, wind in the 
                                paddy fields, abundance of sunshine, world's longest 
                                natural sea beach, rich cultural heritage, relics 
                                of ancient Buddhist civilizations and colorful 
                                tribal lives, - Bangladesh creates an unforgettable 
                                impression of a land of peace.<br>
                                <br>
                                You'll appreciate our culture and the environment. 
                                These are not simply sight-seeing excursions, 
                                but real-time learning experiences. Enjoy an ideal 
                                blend of adventure and exploration with comfort 
                                and relaxation. Here you find that you are not 
                                alone. With us, any place in Bangladesh is a home 
                            away from home.<br></p>
	

	</div>
	<div id="footer" >
	
	 <ul>
<li><a href="travelbd.php">Home</a></li>	  
<li><a href="meetbd.php">Meet Bangladesh</a></li>
<li><a href="travelbangladesh.php">Travel Bangladesh</a></li>
<li><a href="dream.php">Dream Destination</a></li>
<li><a href="tourpackage.php">Tour Packages</a></li>
<li><a href="hotelinbd.php">Hotels in Bangladesh</a></li>
<li><a href="flora.php">Flora & Fauna</a></li>
<li><a href="festival.php">Fair & Festival</a></li>
<li><a href="Transportation.php">Transportation</a></li>

     </ul>
	
	&copy  2018 TravelBD.com.   All Rights Reserved.
	
	</div>
							


</body>
</html>

<?php
	include 'close.php';
?>